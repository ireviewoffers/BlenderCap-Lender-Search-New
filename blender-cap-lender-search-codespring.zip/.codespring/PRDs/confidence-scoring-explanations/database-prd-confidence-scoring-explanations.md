# Database PRD: Confidence Scoring + Explanations
**Feature:** Confidence Scoring + Explanations  
**Type:** database

Feature summary: Persist scoring outcomes and human‑readable explanations for each lender/program match, with reproducible audit logs, guideline rule weights, banding (Strong/Possible/Stretch), and freshness signals used to qualify confidence.

# Scope
- Store lender/program guideline rules mapped to normalized scenario criteria keys.
- Compute and persist per-run, per-program scores, bands, and ranked results.
- Persist granular pass/fail/hard-stop rationales per rule to power “why/why‑not” bullets.
- Maintain configurable score bands and rule weights. Capture freshness signals for confidence attribution.

# Entities & Relationships
- lenders 1—N lender_programs
- lender_programs 1—N guideline_rules (weighted, hard-stops supported)
- criteria_catalog normalizes scenario filter keys used by rules and explanations
- score_bands defines Strong/Possible/Stretch thresholds (per product_type)
- match_runs captures an immutable scoring execution context (filters, engine/version)
- match_results are ranked outputs per run per program; reference bands and summary stats
- match_explanations enumerate rule-level outcomes driving the score and user-visible bullets
- freshness_signals attach to lender/program/rule to inform confidence recency

# Constraints & Behaviors
- Guideline rule operators: EQUALS, NOT_EQUALS, IN, NOT_IN, LT, LTE, GT, GTE, RANGE, EXISTS, BOOLEAN; target_value stores typed data in JSONB.
- Scoring: sum of rule.weight for PASS; FAIL contributes 0; HARD_STOP forces band to lowest and sets hard_stops_count>0. UNKNOWN is allowed when filter not provided, contributes 0 unless weight=0.
- Bands: label must be one of Strong/Possible/Stretch for default set; min_score ≤ max_score. Per product_type, active bands must be non-overlapping and contiguous (enforced in application or via checks/migrations).
- Explanations: rationale text resolved from rule templates; store final rendered text plus outcome and contribution. user_visible flags items safe for UI.
- Auditability: match_runs.filters and scoring_config snapshots ensure result reproducibility; no mutation post-run.
- Freshness: multiple signals may exist; most recent observed_at per entity_type/entity_id is authoritative for UI badges.

# Indexing
- guideline_rules: (lender_program_id), (criteria_id), (active, priority DESC)
- lender_programs: (lender_id, active), (product_type, active)
- score_bands: (product_type, is_default, effective_at DESC)
- match_runs: (scenario_id, executed_at DESC)
- match_results: (run_id, rank ASC), (run_id, total_score DESC)
- match_explanations: (result_id)
- freshness_signals: (entity_type, entity_id, observed_at DESC)

# Retention & Integrity
- Foreign keys cascade DELETE from lenders → programs → rules only when administratively purged; match_* remain immutable for audit (restrict on delete).