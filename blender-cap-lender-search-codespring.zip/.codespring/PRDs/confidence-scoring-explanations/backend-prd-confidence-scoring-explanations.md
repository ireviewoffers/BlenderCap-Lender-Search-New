# Backend PRD: Confidence Scoring + Explanations
**Feature:** Confidence Scoring + Explanations  
**Type:** backend

Feature overview
Confidence Scoring + Explanations ranks eligible lenders for a given loan scenario as Strong, Possible, or Stretch, and returns line-by-line rationales mapped to each borrower filter and lender guideline. This delivers transparent, auditable matching so brokers understand exactly why a lender ranks where it does and what would change the outcome.

Scope & behavior
- Inputs
  - Scenario: scenario_id referencing stored deal details (Residential or Commercial).
  - Optional filters: lender_ids, product_types, geography, max_results, include_explanations (default true).
  - User context: authenticated broker or admin; role-based visibility of lenders/products.
- Outputs
  - Ranked lenders list with:
    - confidence_label: Strong | Possible | Stretch
    - confidence_score: float [0.0–1.0]
    - summary: brief textual summary (1–2 sentences)
    - explanations: structured why/why-not per rule (see Data Model)
    - rule_breakdown aggregates (counts, top blockers, assumptions)
- Matching logic
  - Lender guidelines consist of rules with fields: id, version, field, operator, target_value(s), weight [0–1], criticality: mandatory | preferred | informational, tolerance (for ranges), and exception_policy: none | manual_review.
  - Scenario fields mapped to comparable normalized values (e.g., LTV decimal, FICO int, DSCR float, property_type enum).
  - Rule evaluation states: pass, partial (within tolerance/exception_policy), fail, unknown (missing scenario input).
  - Scoring:
    - Start at 0; sum weight for pass; add 0.5*weight for partial; subtract weight for fail on preferred; mandatory fail sets hard blocker flag.
    - Normalize to [0,1].
  - Confidence labels:
    - Strong: no mandatory fails; unknown rate ≤10%; score ≥0.80.
    - Possible: no mandatory fails; unknown rate ≤25%; score 0.50–0.79 or has partials/warnings.
    - Stretch: has mandatory fail but exception_policy=manual_review OR unknown rate >25% with otherwise viable score.
    - Excluded: mandatory fail with exception_policy=none OR lender inactive/not in geography; excluded lenders are not returned unless debug=include_excluded (admin only).
- Explanations
  - For each evaluated rule, return:
    - why: for pass/partial linking scenario_value and guideline target (e.g., LTV 68% ≤ max 75%).
    - why_not: for fail with deltas (e.g., Min FICO 660, scenario 640, short by 20).
    - unknown_reason when missing inputs.
  - Aggregate rationale includes: top 3 drivers (by weight), blockers, and assumptions taken.
- Validations
  - Scenario must exist, belong to caller (broker) or be accessible by admin.
  - Required base fields by deal type; if missing, mark unknown and degrade score; do not hard fail request unless zero matchable fields.
  - Guideline version lock at evaluation time for auditability.
- Permissions
  - Brokers: may score their own scenarios and view all returned lenders except those marked internal_only.
  - Admins: full access; may request debug views.
  - Lender partners: may request scores only for their lender_id; only see their explanations.
- Performance
  - Max evaluated lenders per request: 200 (paginate over larger sets).
  - P95 latency ≤ 1500 ms for 200 lenders; streaming not required.
  - Cache by (scenario_hash, filter_set, guideline_version_set) TTL 10 minutes; invalidate on scenario update or guideline publish.

User-facing flows
- Broker requests matches for a saved scenario:
  - System validates access, loads normalized scenario, selects candidate lenders by static filters (channel, state, property type).
  - Evaluate rules per lender; compute score, label; filter out excluded (hard blockers).
  - Return top N with explanations; if no lenders, return empty results with no_matches_reason.
- Edge cases
  - Missing FICO/DSCR: mark unknown; degrade score; explanation flags “Data missing: FICO not provided.”
  - Conflicting lender rules (overlapping): pick strictest effective constraint; include note in debug only.
  - Multi-product lenders: evaluate products as separate entries; only top product per lender returned unless include_all_products=true.

API endpoints
- POST /v1/match/score
  - Auth: Bearer token (broker, admin, lender_partner)
  - Request:
    - scenario_id: string (required)
    - filters: { lender_ids?: string[], product_types?: string[], geography?: string[], max_results?: int<=100, include_explanations?: bool=true, include_all_products?: bool=false }
  - Response 200:
    - scenario_id
    - generated_at, guideline_snapshot_id
    - results: [
      {
        lender_id, product_id, confidence_score: number, confidence_label: "Strong"|"Possible"|"Stretch",
        summary: string,
        aggregates: { passed:int, partial:int, failed:int, unknown:int, top_blockers:[{rule_id, title}] },
        explanations: [
          { rule_id, field, operator, target, scenario_value, result:"pass"|"partial"|"fail"|"unknown", criticality, weight, delta?: number, message:string }
        ]
      }
    ]
    - pagination: { returned:int, total_candidates:int, next_cursor?:string }
    - no_matches_reason?: string
  - Errors:
    - 400: invalid_scenario, no_matchable_fields, invalid_filters
    - 401/403: unauthorized, forbidden
    - 409: guideline_version_conflict
    - 500: internal_error

Data considerations
- Persist audit record: match_run {id, scenario_id, user_id, guideline_snapshot_id, request_filters, results_hash, top_10_summaries} for 90 days.
- Guideline versioning: immutable snapshot id used in response for reproducibility.
- Redaction: do not include PII in explanations; show only normalized field values.

Security
- RBAC enforced at scenario and lender visibility.
- Input validation and rate limiting: 30 req/min per broker.
- Signed guideline snapshots to prevent tampering.

Acceptance criteria
- Given a complete scenario, the API returns ≥1 result with label and explanations within 1.5s P95 for 200 lenders.
- Mandatory fails without exception_policy are excluded from results.
- Unknown inputs reduce score and appear in explanations with unknown result and message.
- Labels map deterministically to score/unknown/mandatory-fail rules as defined.
- Responses include guideline_snapshot_id and are reproducible when rerun against that snapshot.
- Lender partners only receive results for their lender_id and cannot infer others.

Out of scope
- UI rendering of explanations, PDF generation, emails.
- Automated data enrichment to fill missing scenario fields.
- Real-time guideline editing tools.