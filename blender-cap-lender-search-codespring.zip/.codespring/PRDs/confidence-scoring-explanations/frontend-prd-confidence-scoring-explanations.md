# Frontend PRD: Confidence Scoring + Explanations
**Feature:** Confidence Scoring + Explanations  
**Type:** frontend

Feature overview
- Display ranked lenders for a scenario as Strong, Possible, or Stretch with visible badges and explanation bullets that map broker inputs to lender guideline rules.
- Enable brokers to quickly understand why a lender ranks where it does, including which filters passed, failed, or were assumed, and what would be needed to improve fit.
- Surface guideline freshness and source context so brokers trust the output.

Scope & behavior
- Placement
  - Search Results page: each lender card shows a match band badge, numeric score (0–100), and collapsible “Why/Why not” section.
  - Comparison page: same badge/score per lender with condensed explanation list; expandable to full list.
- Bands & visual tokens
  - Bands: Strong (80–100), Possible (50–79), Stretch (0–49). Thresholds provided by API; UI only renders labels.
  - Badge styles (AA contrast): Strong = green (#1F7A1F), Possible = amber (#B26B00), Stretch = slate (#4B5563). Include band icon: Strong = check-circle, Possible = info-circle, Stretch = minus-circle.
  - Numeric score displayed beside badge (e.g., 86/100).
- Explanations content model (per lender result)
  - Group by broker filter category: Program, Loan Amount, LTV/CLTV, DSCR/DTI, Credit Score, Property Type, Occupancy, Geography, Purpose, Term/Amortization, Prepay, Documentation, Special Conditions.
  - Each line: status icon + short label + value comparison + source tag.
    - Status icon: pass = check, fail = x, borderline = tilde, unknown/assumed = question.
    - Example: check “LTV: 68% ≤ 75% max (Purchase)” [Guideline v3.2, updated 2026‑04‑10]
  - Show up to 5 lines by default; “Show all (n)” expands inline. Persist expansion state per lender during session.
  - Order lines: failures first, then borderline, then passes, then unknowns.
  - Hover/press (mobile tap) on source tag opens tooltip sheet with: guideline source (program name), last updated date, and any footnote text from API.
- Sorting and bands legend
  - Default sort: by band (Strong > Possible > Stretch), then by score desc. Ties: fresher guidelines first (per API freshness rank), then alphabetical by lender name.
  - Results header includes “Match bands” legend with the three badges and brief definitions.
- States
  - Loading: skeleton for badge, score, and 4–6 placeholder lines.
  - Empty: show neutral state “No lenders match. Loosen filters to see Possible/Stretch options.” with quick links to adjust key filters.
  - Partial data: if explanations missing but score present, show badge/score and a warning chip “Limited explanations unavailable.”
  - Stale data: display clock icon and “Guidelines updated >90 days ago” tooltip via freshness flag from API.
  - Error: inline retry on card if per-lender explanation fetch fails; global banner if all fail.
- Interactions
  - Click/press anywhere on the lender card’s “Why/Why not” row toggles expansion; chevron indicates state. Keyboard accessible (Enter/Space).
  - Copy link: overflow menu > “Copy rationale link” copies deeplink with lenderId and scenarioId; expansion opens on load.
  - Comparison handoff: selected lenders retain expanded/collapsed rationale state when navigating to comparison.
- Permissions
  - Authenticated brokers: full badge, score, and explanations.
  - Unauthenticated: obfuscated score (“–”), band only, and “Sign in to view explanations.”

User-facing flows
- From results
  1) Broker submits scenario → results render sorted by band/score.
  2) Broker expands a lender → sees failure reasons first and actionable gaps (e.g., “Needs DSCR ≥ 1.15; you have 1.10”).
  3) Broker taps source tag to confirm freshness; optionally opens all lines.
  4) Broker selects lenders to compare; states persist into comparison view.
- Edge cases
  - Multiple programs match: show best-fit program’s rationale by default with a “Programs (1 of N)” pill; tap to cycle or open a program picker modal.
  - Conflicting guidelines returned: show both lines with a “conflict” warning icon and note “Program rules conflict; verify with lender.”
  - Long text/footnotes: truncate at 1 line with “more” expander in tooltip.
  - Mobile: tooltips render as bottom sheets; expansion affordances are 44px touch targets.

Acceptance criteria
- Renders band badge and numeric score for each lender; colors and icons match tokens; meets WCAG AA contrast.
- Results are sorted by band then score; tie-breaking as specified.
- Explanations list shows failures first, then borderline, passes, unknowns; default shows up to 5 lines with expandable full list.
- Each line displays status icon, short label, value comparison, and source tag with tooltip/sheet including last-updated date.
- Hover/tap on source shows freshness and program name; stale flag presents clock icon with “>90 days” text when applicable.
- Expansion state persists across navigation to comparison and back during the session.
- Unauthenticated users see bands only; authenticated users see full scores and explanations.
- Loading skeletons, empty state, partial-data warning, and error retry behaviors are present.
- Keyboard navigation works: tab order logical; toggle via Enter/Space; focus states visible.
- Screen reader labels announce band, numeric score, and count of rationale items; each line includes status in aria-label (e.g., “Fail: DSCR 1.10; requires ≥1.15”).

Out of scope
- Score computation, rule weighting, or guideline authoring.
- Backend audit logs or analytics pipelines.
- PDF/email export formatting of explanations.
- Lender outreach/messaging or document uploads.
- Persisting user-customized sort orders or filters beyond current session.