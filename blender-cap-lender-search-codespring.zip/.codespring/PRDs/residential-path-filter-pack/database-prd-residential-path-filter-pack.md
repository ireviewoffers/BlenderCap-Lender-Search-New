# Database PRD: Residential Path — Filter Pack
**Feature:** Residential Path — Filter Pack  
**Type:** database

## Residential Path — Filter Pack (DB Scope)
A normalized schema to capture and query residential search filters used to match lenders for a loan scenario. The filter pack binds to a scenario and stores normalized selections for: loan purpose, property subtype, occupancy, geography (state/city), FICO band, LTV range, documentation preference (DSCR/No‑Doc/Full), and desired closing speed.

### Entities
- residential_filter_pack: One-to-one (or latest active) filter record per residential scenario. Serves search engine with normalized filter signals.
- loan_purposes: Controlled vocab (e.g., purchase, rate_term_refi, cash_out_refi).
- property_subtypes: Controlled vocab for residential subtypes (SFR, condo, townhome, 2_4_unit, STR).
- occupancies: Controlled vocab (owner_occupied, second_home, investment).
- fico_bands: Labeled, non-overlapping min/max bands for borrower FICO input.
- states: 2-letter USPS codes for normalization and validation.

### Relationships
- residential_filter_pack.scenario_id → scenarios.id (FK; scenarios table exists elsewhere).
- residential_filter_pack.loan_purpose_id → loan_purposes.id (FK).
- residential_filter_pack.property_subtype_id → property_subtypes.id (FK).
- residential_filter_pack.occupancy_id → occupancies.id (FK).
- residential_filter_pack.fico_band_id → fico_bands.id (nullable FK; unknown/no score allowed).
- residential_filter_pack.state_code → states.state_code (FK).

### Constraints & Validation
- residential_filter_pack:
  - ltv_min and ltv_max NUMERIC(5,2) represent percentages (0–100). CHECK 0 <= ltv_min <= ltv_max <= 100.
  - doc_pref TEXT CHECK IN ('full_doc','dscr','no_doc').
  - city is optional; if provided, trimmed and stored case-insensitively (application ensures casing; DB can index lower(city)).
  - closing_speed_days INT CHECK > 0 (nullable if not specified).
  - One active pack per scenario: UNIQUE (scenario_id) WHERE is_active = true.
- fico_bands:
  - CHECK 300 <= min_fico <= max_fico <= 850.
  - Non-overlapping: EXCLUDE USING GIST (int4range(min_fico, max_fico, '[]') WITH &&) DEFERRABLE INITIALLY IMMEDIATE.
- Reference tables enforce is_active flags to allow soft evolution without breaking FKs.

### Indexing (filter performance)
- residential_filter_pack:
  - BTREE on (state_code, property_subtype_id, occupancy_id, loan_purpose_id).
  - BTREE on fico_band_id.
  - BTREE on doc_pref.
  - Functional index on lower(city).
  - For LTV range matching by engine, GIST on numrange(ltv_min, ltv_max, '[]').
- fico_bands: BTREE on (min_fico, max_fico) and GIST on int4range(min_fico, max_fico, '[]').

### Data Rules
- STR (short-term rental) is represented as property_subtypes.code = 'str'; does not imply occupancy (must be provided independently).
- DSCR/no-doc is captured on doc_pref and independent of FICO; fico_band_id may be NULL for no-score programs or when unknown.
- City without state is invalid; state_code is required for all packs.
- Closing speed is broker-requested target in days; NULL means no preference.

### Edge Cases
- If ltv_min is omitted, default to 0; if ltv_max omitted, default to 100 (application-level defaults; DB allows NULLs only if both provided? Recommended: require both, enforce range constraint).
- Scenarios can be cloned; cloned packs should set is_active on new record and deactivate prior pack for the new scenario instance.
- If a referenced vocab row is deactivated, existing packs remain valid; creation of new packs must use active rows only.
