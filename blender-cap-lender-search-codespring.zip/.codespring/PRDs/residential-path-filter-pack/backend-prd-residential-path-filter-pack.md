# Backend PRD: Residential Path — Filter Pack
**Feature:** Residential Path — Filter Pack  
**Type:** backend

# Residential Path — Filter Pack (Backend)

## Feature overview
Enable brokers on the Residential path to narrow lender matches using structured filters: loan purpose, property subtype, occupancy, geography, FICO band, LTV, DSCR/No‑doc, and closing speed. The backend will expose validated filter metadata and accept filter payloads to prefilter the lender universe before scoring, ensuring fast, accurate matches with explicit rejection reasons for invalid inputs.

## Scope & behavior
- Filters (Residential only):
  - loanPurpose: purchase | rate_term_refi | cash_out_refi | bridge
  - propertySubtype: sfr | condo | townhome | two_to_four_unit | short_term_rental
  - occupancy: owner_occupied | second_home | investment
  - geography: state (US 2‑letter), optional city (dependent on state; free‑text with canonicalization)
  - ficoBand: lt_620 | 620_659 | 660_679 | 680_699 | 700_719 | 720_739 | gte_740
  - ltv: number (0–100 with up to 2 decimals)
  - underwritingPath: dscr | full_doc | no_doc (mutually exclusive; dscr requires dscrValue)
  - dscrValue: number (0.00–3.00) required if underwritingPath=dscr
  - closingSpeedDays: integer (5–90)
- Permissions: Authenticated users with role broker or lender_partner may request metadata; only broker role can execute residential match searches using this filter pack.
- Validation/Rules:
  - propertySubtype=short_term_rental requires occupancy=investment or second_home; reject owner_occupied.
  - two_to_four_unit permitted with any occupancy; condo/townhome/SFR permitted with any occupancy.
  - loanPurpose=bridge implies underwritingPath cannot be full_doc_only lenders if lender rules exclude; backend will still accept but matching will filter accordingly.
  - ficoBand must align with declared band edges; raw FICO values are not accepted here.
  - ltv must be <= max allowed by loanPurpose and occupancy at lender filter stage; input range check is 0–100 only.
  - dscrValue required and >0 if underwritingPath=dscr; disallowed if underwritingPath in {full_doc, no_doc}.
  - city requires state present; when city provided, normalize via places table; unrecognized city returns 400 with suggestion candidates.
  - closingSpeedDays maps to lender SLA buckets: rush (<=10), fast (11–21), standard (22–35), slow (>35).
- Error handling:
  - 400 on schema/semantic validation failures with code and field-specific messages.
  - 403 on role violations.
  - 422 when combination is logically inconsistent (e.g., owner_occupied + short_term_rental).
- Security: OAuth2/JWT; PII not accepted in this payload. Log requests with hashed userId.

## User-facing flows
- Fetch filter metadata (for UI population):
  - GET /v1/residential/filters
  - Returns enumerations, current state/city lists (paged), band definitions, numeric constraints.
- Execute filter-based prefilter + match:
  - POST /v1/residential/search
  - Body: filterPack object as below. Backend validates, normalizes geography, derives SLA bucket, applies prefilter to lender rules, then calls scoring engine with filtered lender set and filter context. Returns paginated lender matches.

## API contracts
- GET /v1/residential/filters
  - Auth: required
  - Query: state=CA (optional, to fetch cities)
  - 200: {
      loanPurpose: [...],
      propertySubtype: [...],
      occupancy: [...],
      ficoBands: [{key:"620_659", min:620, max:659}],
      ltv: {min:0, max:100, step:0.01},
      underwritingPath: [...],
      closingSpeedDays: {min:5, max:90},
      states: ["CA","NY",...],
      cities: [{name:"Los Angeles", state:"CA", canonicalId:"..."}]
    }
- POST /v1/residential/search
  - Auth: broker
  - Body: {
      loanPurpose, propertySubtype, occupancy,
      geography: {state, city}, ficoBand, ltv,
      underwritingPath, dscrValue?, closingSpeedDays,
      pagination: {page, pageSize}
    }
  - 200: {
      matches: [{lenderId, score, reasons:[...], slaBucket, maxLTV, minFICO, docsType}],
      page, pageSize, total
    }
  - 400/422/403 with {code, message, fields?}

## Performance requirements
- GET filters: p95 < 300 ms.
- POST search (prefilter + scoring call): p95 < 1500 ms; must handle 50 QPS burst with caching of metadata and geography normalization.

## Acceptance criteria
- GET /v1/residential/filters returns stable, cacheable metadata with ETag and 200 on authenticated request.
- POST rejects owner_occupied + short_term_rental with 422 code=INVALID_COMBINATION.
- POST requires dscrValue when underwritingPath=dscr; returns 400 code=MISSING_FIELD when absent.
- City without state returns 400 code=MISSING_STATE.
- FICO band outside allowed keys returns 400 code=INVALID_ENUM.
- LTV > 100 or < 0 returns 400 code=OUT_OF_RANGE.
- closingSpeedDays=9 maps to slaBucket=rush in response.
- Successful search returns only lenders whose baseline rules match all provided filters (e.g., state eligibility, minFICO, maxLTV, product/occupancy support).
- Unauthorized role receives 403 code=FORBIDDEN.
- All responses include requestId header for traceability.

## Out of scope
- Commercial path filters
- Full scenario creation, cloning, and persistence
- Pricing, rate quotes, or fee calculations
- Document generation, email, or notifications
- UI rendering; this spec is backend contracts only