# Frontend PRD: Residential Path — Filter Pack
**Feature:** Residential Path — Filter Pack  
**Type:** frontend

# Residential Path — Filter Pack

## Feature overview
A compact, mobile-friendly filter pack for the Residential path that narrows lender matches based on real underwriting criteria. Brokers can quickly specify loan purpose, property subtype, occupancy, geography, borrower profile (FICO/LTV), documentation type (DSCR/No‑doc), and required closing speed. Filters update matches in real time with clear visual state and are shareable via URL.

## Scope & behavior
- Entry point
  - Visible only in Residential path after authentication (Broker role).
  - Renders above results list; mobile displays a “Filters (n)” button that opens a full-height bottom sheet.

- Components and states
  - Loan Purpose (single-select segmented): Purchase, Rate/Term Refi, Cash‑Out Refi. Required; default = Purchase.
  - Property Subtype (multi-select chips): SFR, Condo, Townhome, 2–4 Unit, STR (Short‑Term Rental). Default = Any (no chips selected). Selecting ≥1 limits results to those subtypes.
  - Occupancy (single-select chips): Owner‑Occupied, Second Home, Investment. Default = Any.
  - Geography:
    - State (typeahead dropdown of US states/territories). Required for City enablement. Default = Any.
    - City (typeahead; disabled until State chosen). Matches cities within selected State. Clear X resets City only.
  - FICO
    - Min FICO numeric field (300–850), step 1; default blank (no constraint).
    - Preset chips (optional quick-set): 620, 660, 700, 740. Tapping sets Min FICO to that value.
    - Validation: non-integer or out-of-range shows inline error and blocks apply.
  - LTV
    - Numeric field (%) with slider 0–100, step 1; default blank (no constraint).
    - Validation: 0–100 inclusive; show inline error if invalid.
    - Hint: “Enter deal LTV; results hide lenders with lower max LTV.”
  - Documentation Type (single-select): Full Doc, DSCR, No‑Doc. Default = Any.
    - Context note icon clarifies DSCR = cash‑flow underwriting, No‑Doc = minimal income verification.
  - Closing Speed
    - Max Days to Close numeric field with preset chips: 7, 14, 21, 30, 45+. Default blank (no constraint).
    - Validation: 5–120; 45+ chip sets 60.
  - Apply model
    - Desktop: changes apply immediately with 300 ms debounce; “Reset all” link visible.
    - Mobile sheet: has “Apply” (primary) and “Reset” (secondary). Invalid inputs disable Apply and surface inline errors.
  - Summary chips bar shows active filters with x-removal; “Clear all” resets to defaults.
  - Result count badge updates live; skeleton state while querying.
  - Empty state: “No lenders match. Try: Clear all | Broaden property types | Lower Min FICO | Increase Max Days.” Quick actions adjust filters.

- URL/state
  - Filters sync to URL query params; back/forward restores state. Session persistence for authenticated users via local storage fallback.

- Accessibility
  - All controls labeled; role=button for chips; keyboard operable; focus outline; status updates via aria-live for result count changes. Color contrast ≥ 4.5:1.

- Errors
  - Per-field inline errors; global error toast on fetch failures with retry. City field shows helper text if State not selected.

## User-facing flows
1) Open Residential path → tap Filters (mobile) or view panel (desktop) → set Loan Purpose, subtype chips, Occupancy → select State then City → set Min FICO and LTV → choose Doc Type and Max Days → Apply (mobile) or auto-apply (desktop) → view updated results and summary chips.
2) Clear all → defaults restored; results requery.
3) Share URL → recipient sees identical filter state and results (subject to permissions).

## Acceptance criteria
- Loan Purpose, Property Subtype, Occupancy rendered with specified defaults and selection rules.
- State typeahead enables City; City suggestions constrained to State; City disabled until State chosen.
- Min FICO (300–850) and LTV (0–100%) validate with inline errors; invalid blocks Apply on mobile and prevents auto-apply on desktop until corrected.
- Doc Type options match spec; default Any.
- Closing Speed numeric with presets; 45+ sets 60; validates 5–120.
- Debounced (300 ms) queries on desktop; mobile requires Apply.
- Active filters summarized as removable chips; Clear all resets all fields.
- URL query params reflect filters; back/forward restores state; reload preserves filter state.
- Live result count updates; loading skeleton shown; empty state with actionable quick adjustments.
- Fully keyboard accessible; aria-live announces result updates; contrast meets WCAG AA.
- Mobile bottom sheet is full-height, swipe-to-dismiss with discard confirmation if unsaved edits exist.

## Out of scope
- Commercial path filters
- Pricing/rate quotes, lender contact
- Saving/templating scenarios beyond URL persistence
- Advanced geography (ZIP radius, multi-state)
- Income/DTI calculators, product selection, prequalification letters