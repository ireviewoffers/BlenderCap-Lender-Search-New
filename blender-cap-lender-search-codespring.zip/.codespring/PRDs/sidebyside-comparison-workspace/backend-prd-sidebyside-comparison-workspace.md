# Backend PRD: Side‑by‑Side Comparison Workspace
**Feature:** Side‑by‑Side Comparison Workspace  
**Type:** backend

Feature overview
Side‑by‑Side Comparison Workspace provides a structured, stable snapshot of multiple matched lenders/programs from a single loan scenario so brokers can compare key underwriting attributes side‑by‑side. The backend supplies a normalized data contract for comparison, preserves point‑in‑time guideline values, supports limited sharing/export, and enforces access, validation, and performance constraints.

Scope & behavior
- Entities
  - ComparisonSession
    - id, scenario_id, org_id, owner_user_id
    - lender_program_columns[] (ordered)
    - attribute_set (fixed for this feature)
    - snapshot_at (UTC), status: active | stale | deleted
    - metadata: title, notes, share_token (optional), share_expires_at (optional)
  - LenderProgramSnapshot (embedded per column)
    - lender_id, lender_name, program_id, program_name, confidence_score
    - normalized_attributes (see Data contract)
    - explanations[] (rationale per attribute)
    - ineligible_attributes[] (for transparency)
- Attribute set (fixed; always returned in this order):
  - leverage, min_fico, docs, prepay, size, geo_appetite, entity_rules, seasoning, str, rehab_draws, valuation, timeline
- Normalization rules (high‑level)
  - Leverage: max_ltv_pct, max_ltc_pct; include conditions notes if varied by occupancy/loan size.
  - Min FICO: integer 300–850; null with reason if N/A (e.g., asset‑based).
  - Docs: enum list (e.g., FULL, ALT, BANK_STATEMENT, NO_DOC); include required months if applicable.
  - Prepay: object {type: enum YIELD_MAINT | STEP_DOWN | NONE | LOCKOUT, details string, term_months int?}
  - Size: {min: currency, max: currency or null for unlimited}
  - Geo appetite: {nationwide bool, include_states[], exclude_states[]}
  - Entity rules: {allowed_entities[], guarantor_required bool, foreign_national_allowed bool}
  - Seasoning: {title_seasoning_months?, cash_out_months?, rehab_complete_months?}
  - STR: {allowed bool, dscr_min? number, ltv_cap_pct?}
  - Rehab draws: {allowed bool, holdback_pct?, min_draw_amt?, max_draws?}
  - Valuation: {types_allowed[], appraisal_age_max_days?}
  - Timeline: {term_sheet_days?, closing_days?}
  - All fields may carry notes string for caveats; nulls accompanied by reason.
- Snapshotting and staleness
  - On creation, the service snapshots matched lender program attributes and explanations based on the current scenario inputs and matching engine output.
  - If underlying guidelines/program availability change later, ComparisonSession remains stable (status=active) until an explicit refresh. A background job can mark sessions stale when source guideline versions advance.
- Permissions
  - Create/list/get/update/delete: scenario owner and org members with SCENARIO_EDIT; read: SCENARIO_VIEW.
  - Share token (read‑only) grants GET to the comparison for unauthenticated viewers until expiration; no PII beyond lender/program and normalized attributes.
- Limits and validations
  - Max compared columns per session: 6; min: 2.
  - Lenders/programs must exist in the parent scenario’s latest match result at creation time.
  - Scenario must be in state saved (not draft‑unsaved).
  - Title max 140 chars; notes max 5,000 chars.
- Performance/SLA
  - GET /comparisons/{id}: p95 ≤ 500 ms for up to 6 columns.
  - Exports queued; response ≤ 300 ms; delivery via async job.
- Security
  - Auth via bearer JWT; org scoping on scenario_id.
  - Share tokens: opaque, 128‑bit entropy, single comparison scope, default TTL 14 days, revocable.

User-facing flows
- Create comparison from scenario results
  - Input: scenario_id, lender_program_ids[] (2–6), optional title.
  - System validates membership, availability, and deduplicates by program_id.
  - System snapshots attributes/explanations and returns ComparisonSession.
- Retrieve comparison
  - Returns ordered columns with normalized attributes and explanations; includes status and stale flag.
- Update comparison
  - Reorder columns; add/remove columns (must remain 2–6, added items must be from scenario’s latest results).
  - Optional refresh_snapshot=true to re‑snapshot from latest guidelines; sets previous_snapshot_id for audit.
- Share/export
  - Create share token (read‑only). Export to PDF or CSV (emails optional); jobs emit notifications on completion.
- Edge cases
  - Program removed or lender paused: column remains with status=unavailable; refresh will drop unless present in latest results.
  - Missing attribute data: null with reason and appears in ineligible_attributes if it affects eligibility.

API endpoints
- POST /scenarios/{scenario_id}/comparisons
  - Body: {title?, notes?, lender_program_ids: [uuid, 2–6]}
  - 201 -> ComparisonSession resource
  - 400 on invalid counts/duplicates; 403 on permissions; 409 if scenario has no match snapshot
- GET /comparisons/{id}
  - Query: token? (for share access)
  - 200 -> ComparisonSession with columns and normalized_attributes
  - 401/403/404 as appropriate
- PATCH /comparisons/{id}
  - Body: {title?, notes?, column_order?: [uuid], add_lender_program_ids?: [uuid], remove_lender_program_ids?: [uuid], refresh_snapshot?: bool}
  - 200 -> updated resource; 409 if resulting columns <2 or >6
- DELETE /comparisons/{id}
  - 204
- POST /comparisons/{id}/share
  - Body: {ttl_days?: 1–30}
  - 201 -> {share_url, expires_at}
- DELETE /comparisons/{id}/share
  - 204 (revokes token)
- POST /comparisons/{id}/export
  - Body: {format: PDF|CSV, email_to?: [email]}
  - 202 -> {job_id}; later webhook/notification carries artifact url

Data contract (response excerpt)
- ComparisonSession
  - id, scenario_id, title, notes, status, stale: bool, snapshot_at, columns: [
    {
      lender_id, lender_name, program_id, program_name, confidence_score,
      normalized_attributes: {
        leverage: {max_ltv_pct?, max_ltc_pct?, notes?},
        min_fico: {value?, reason?},
        docs: {types: [enum], months_bank_statements? int, notes?},
        prepay: {type, term_months?, details?, notes?},
        size: {min, max?, notes?},
        geo_appetite: {nationwide, include_states[], exclude_states[]},
        entity_rules: {allowed_entities[], guarantor_required?, foreign_national_allowed?, notes?},
        seasoning: {title_seasoning_months?, cash_out_months?, rehab_complete_months?, notes?},
        str: {allowed, dscr_min?, ltv_cap_pct?, notes?},
        rehab_draws: {allowed, holdback_pct?, min_draw_amt?, max_draws?, notes?},
        valuation: {types_allowed[], appraisal_age_max_days?, notes?},
        timeline: {term_sheet_days?, closing_days?, notes?}
      },
      explanations: [{attribute, text}],
      ineligible_attributes: [attribute]
    }
  ]

Acceptance criteria
- Creating a comparison with 2–6 valid lender_program_ids from the scenario returns 201 with a stable snapshot and ordered columns.
- GET returns all attributes for each column in the specified order; nulls include a reason field where applicable.
- Updating order or adding/removing columns preserves 2–6 constraint and returns 200; attempting invalid counts returns 409.
- Refreshing snapshot updates attributes to latest guidelines, sets stale=false, updates snapshot_at, and records previous snapshot for audit.
- If a program becomes unavailable, existing columns show status=unavailable and are included until refresh.
- Share token grants read‑only GET without standard auth until expiry; revocation immediately invalidates the link.
- Export enqueues a job and delivers a PDF/CSV that matches the current snapshot values and order.
- All endpoints enforce org‑scoped permissions; access to unrelated scenario_id returns 403.

Out of scope
- UI rendering and interactions
- Editing lender guidelines/program data
- Real‑time multiuser collaboration within the workspace
- Custom attribute definitions or weighting logic
- Price/rate quoting; term sheet generation beyond PDF/CSV of the comparison snapshot