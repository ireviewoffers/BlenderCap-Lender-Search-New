# Database PRD: Side‑by‑Side Comparison Workspace
**Feature:** Side‑by‑Side Comparison Workspace  
**Type:** database

## Feature Summary
Persist user-created side-by-side comparison workspaces for a single loan scenario, capturing a frozen snapshot of lender attributes at time of comparison. Enables ordering, inclusion/exclusion, winner selection, and configurable visible fields for PDF/email outputs.

## Scope & Entities
- Comparison Workspace: container tied to one scenario and owner.
- Comparison Entry: one lender (or specific lender offer) included in the workspace with a snapshot of comparable attributes (leverage, min FICO, docs, prepay, size, geography, entity rules, seasoning, STR, rehab draws, valuation, timeline).
- Visible Fields: per-workspace field configuration controlling which attributes display and their order.

## Relationships
- comparison_workspace.scenario_id → scenarios.id (existing)
- comparison_workspace.owner_user_id → users.id (existing)
- comparison_entry.comparison_id → comparison_workspace.id
- comparison_entry.lender_id → lenders.id (existing)
- comparison_entry.lender_offer_id → lender_offers.id (existing, optional)

## Data Model Notes
- Snapshot at comparison time is mandatory to prevent drift when lender guidelines update. Each comparison_entry stores explicit scalar columns for key attributes plus a flexible attributes JSONB for extensibility.
- Either lender_offer_id (preferred when available) or lender_id must be set. Both can be set to reference the parent lender and a concrete offer.
- Product type (Residential/Commercial) is tracked on the workspace to standardize displayed fields.

## Constraints & Validation
- A workspace must reference exactly one scenario and one owner.
- Each comparison_entry must have at least one of lender_offer_id or lender_id; prevent duplicate entries for the same lender/offer within a workspace using partial unique indexes.
- rank is unique per workspace when set (deterministic ordering); null allowed for unranked.
- Archived workspaces and entries are excluded from default queries via archived_at IS NULL.

## Indexing Strategy
- comparison_workspace: BTREE on (owner_user_id, scenario_id, archived_at NULLS FIRST).
- comparison_entry: BTREE on (comparison_id), (lender_id), (lender_offer_id), (is_winner), (rank).
- JSONB GIN indexes on geo_footprint and attributes for filtering and reporting.

## Edge Cases
- Attributes with multiple representations (e.g., prepay, valuation) are captured as normalized text plus JSON details for fidelity.
- Geography supports ISO country/state codes array; empty array means nationwide; null means unknown.
- Leverage supports both LTV and LTC; nulls allowed when not applicable.
- Seasoning in months; -1 disallowed; use null for unknown.

## Retention & Auditing
- Timestamps on all entities; archived_at serves soft delete.
- notes fields allow broker annotations per entry without affecting snapshots.
