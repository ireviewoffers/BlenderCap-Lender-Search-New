# Frontend PRD: Side‑by‑Side Comparison Workspace
**Feature:** Side‑by‑Side Comparison Workspace  
**Type:** frontend

# Side‑by‑Side Comparison Workspace

## Feature overview
A responsive workspace that lets brokers compare multiple matched lenders side‑by‑side for a given scenario. Displays key criteria and terms (e.g., leverage, min FICO, docs, prepay, size, geo appetite, entity rules, seasoning, STR, rehab draws, valuation, timeline) with clear pass/fail indicators against the scenario and concise rationale. Optimized for quick screening, highlighting differences and potential blockers, with optional export for client/partner sharing.

## Scope & behavior
- Access & permissions
  - Available to authenticated users from a scenario’s results view.
  - Brokers can compare any lenders returned by the matching engine for their scenario.
  - Sharing/export allowed only for authenticated users with access to the scenario.

- Data & normalization
  - All attributes normalized to consistent units and labels:
    - Leverage: LTV/LTC/LTV+Rehab (%), show type + max percent.
    - Min FICO: integer score.
    - Docs: doc type (e.g., Full, Lite, Bank Statements, DSCR).
    - Prepay: structure (e.g., 3-2-1, stepdown, yield maintenance), show term and penalties.
    - Size: min/max loan amount (USD), abbreviations (e.g., $250k–$5MM).
    - Geo appetite: states/regions; show “Nationwide” if all 50 states, else list up to 3 + “+N more”.
    - Entity rules: allowed borrower entities (LLC, LP, Trust, Corp), special restrictions.
    - Seasoning: months since acquisition/DSCR history; show “N/A” when not required.
    - STR: short‑term rental policy (Allowed/Case‑by‑case/Not allowed) + DSCR/airDNA notes if available.
    - Rehab draws: allowed (Yes/No), max draws, holdback %, inspection rules.
    - Valuation: accepted methods (Appraisal, BPO, AVM), recency limits.
    - Timeline: typical days to term sheet and to close.
  - Missing data displays as “Not provided” with neutral styling and tooltip.

- Layout & responsiveness
  - Desktop/tablet: sticky left attribute column; lender columns scroll horizontally; max 5 columns visible; resize on viewport.
  - Mobile: show 2 columns at a time with horizontal swipe; sticky attribute column; column switcher chips.
  - Column header includes lender name, program type, confidence score, and pin/close controls.

- Interactions
  - Add/remove lenders: multi‑select from results; remove via column close; max selected = 5 (desktop) / 4 (tablet) / 3 (mobile, shown 2 at a time).
  - Reorder columns via drag handle or “Move left/right” actions.
  - Pin a lender column to keep it visible while scrolling horizontally.
  - Toggle “Show differences only” to hide identical rows; always keep rows with scenario conflicts.
  - Scenario fit indicators per attribute:
    - Pass (green check), Conditional (amber dot with note), Fail (red x).
    - Tooltip explains rationale (e.g., “Min FICO 680 > Borrower 660”).
  - Row grouping: Eligibility (min FICO, entity rules, seasoning, geo), Terms (leverage, size, docs, prepay, timeline), Special (STR, rehab draws, valuation).
  - Tooltips on jargon; click “i” to view brief definition and source notes.
  - Export: generate PDF of current comparison state (selected lenders, ordering, toggles) and email/share via system action.

- States & errors
  - Empty: prompt to select lenders (with link back to results).
  - Loading per column with skeleton; partial render allowed.
  - Error per column on fetch failure with retry.
  - Permission error: hide export and show “Upgrade/Login” CTA if unauthenticated.

- Accessibility
  - Keyboard navigation for column focus, reorder, and toggles.
  - ARIA roles for grid; focus outlines; 4.5:1 contrast for indicators.
  - Tooltips accessible via keyboard and dismissible.

## User-facing flows
- Launch comparison
  - From results: user selects 2–5 lenders and clicks “Compare.” Workspace opens pre‑populated.
  - Edge: selecting > limit shows inline message and disables extra selections.

- Manage columns
  - Pin primary lender, reorder others to adjacent positions, remove a lender; grid updates without full reload.

- Evaluate fit
  - Toggle “Show differences only.” Review pass/fail icons and rationale tooltips.
  - Expand truncated geo lists and prepay details on click.

- Export/share
  - Click Export → PDF preview modal → Confirm. On success: toast with download; optional email to client.

- Mobile specifics
  - Swipe between lender columns; column picker to jump; attribute column stays fixed; actions in bottom sheet.

## Acceptance criteria
- Users can add up to the platform‑specified max lenders and see them in side‑by‑side columns with a sticky attribute list.
- All listed attributes render with normalized units and consistent formatting; missing values show “Not provided.”
- Scenario fit icons compute correctly based on scenario inputs and lender criteria for each row.
- “Show differences only” hides rows identical across all visible lenders while keeping any with pass/fail variance.
- Column pinning keeps the pinned column visible while horizontally scrolling others.
- Reordering updates column positions and persists during the session.
- Mobile shows exactly 2 columns at a time with swipe; desktop supports horizontal scrolling and sticky headers.
- Tooltips provide definitions and rationale; accessible via keyboard and screen readers.
- Per‑column loading skeletons render, and errors display with retry without blocking other columns.
- Export generates a PDF matching current selection, order, and toggle states; unauthenticated users cannot export.

## Out of scope
- Editing lender profiles or criteria.
- Negotiation, messaging, or document uploads.
- Pricing calculators, payment schedules, or rate locks.
- Backend scoring/matching logic changes.
- Persistent saving of comparison snapshots beyond export (separate feature).