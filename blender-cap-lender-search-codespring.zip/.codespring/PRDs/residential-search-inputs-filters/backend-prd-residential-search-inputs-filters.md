# Backend PRD: Residential Search Inputs & Filters
**Feature:** Residential Search Inputs & Filters  
**Type:** backend

Feature overview
Enables brokers to submit standardized Residential loan search criteria and retrieve filter metadata. The backend validates, normalizes, and persists inputs, producing a search_id used by the matching engine. It enforces mandatory fields, supports bands/presets, and returns inline hints to guide feasible selections.

Scope & behavior
- Roles and auth
  - Requires authenticated user with role broker or lender_partner to access metadata and create searches.
  - Rate limit: 60 req/min per user for metadata; 20 req/min per user for search creation.
- Data model (search_criteria)
  - purpose: enum [purchase, rate_term_refi, cash_out_refi] (required)
  - amount: number in USD; either raw amount or amount_band (mutually exclusive). Required: one of them.
    - amount_min/amount_max populated if band provided.
  - property_type: enum [sfr, condo, townhome, two_to_four_unit, multifamily_5_plus] (required; 5+ marked advanced via metadata)
  - occupancy: enum [owner_occupied, second_home, investment] (required)
  - location: state (ISO USPS 2-letter; required), city (string; optional; validated against state list if provided)
  - fico_band: enum bands or no_minimum (required). Canonical bands: [500_579, 580_619, 620_659, 660_679, 680_699, 700_719, 720_739, 740_plus, no_minimum]
  - ltv_pct: float 0–100; snapped to nearest of [50,60,70,80,90] using standard rounding at .5 (required)
  - docs_type: enum [full, bank_statements, stated, no_doc, dscr] (required)
  - borrower_type: enum [individual, llc_corp, trust, foreign_national] (optional)
  - product_type: enum [fixed_30, fixed_15, arm_5_6, arm_7_6, arm_10_6]; interest_only: boolean (optional)
  - closing_speed: enum [asap, le_7_days, le_14_days, le_21_days, le_30_days, gt_30_days] (optional)
  - source: enum [residential] fixed
  - created_by, created_at; status: [validated, invalid]
- Validation and normalization
  - amount: parse currency-formatted strings; > 0; upper cap 50,000,000. Bands map to amount_min/amount_max; if both raw and band provided, 400.
  - ltv_pct: 0 <= value <= 100; after snapping store snapped_ltv; retain original_ltv for audit.
  - fico_band: must be one of canonical bands; no arbitrary numbers.
  - city: if provided, must match a known city within state; fallback to case-insensitive, diacritic-insensitive match; else 422 with suggestion list.
  - Cross-field rules:
    - docs_type=dscr requires occupancy=investment; else 422 code=conflict.dscr_occupancy.
    - property_type=multifamily_5_plus requires occupancy=investment or second_home; else 422 code=conflict.mf5plus_occupancy.
  - Progressive disclosure: enforced via metadata flags only; server still validates all required fields even if UI hides advanced.
- Hints and presets
  - Metadata includes typical_ltv_caps and typical_min_fico by (property_type, occupancy).
  - Presets return named bundles: e.g., “Investor DSCR”, “Conventional W2”, “Bank Statement”.
- Performance
  - Metadata cached 15 minutes; P95 < 150 ms.
  - Search creation P95 < 300 ms excluding downstream matching; returns immediately with search_id.

API endpoints
- GET /v1/residential/filters/metadata
  - Auth required.
  - Response: enums, required/optional flags, advanced=true for optional fields, allowed bands, presets, validation constraints (min/max), hint matrices, example values.
  - 200 JSON
- GET /v1/locations/suggest?q={string}&state={USPS}
  - Returns up to 10 city suggestions for the given state; 400 if state missing.
- POST /v1/residential/search
  - Auth required.
  - Body: search_criteria fields above; accepts amount or amount_band key {label, min, max}.
  - Behavior: validate -> normalize -> persist -> emit event search.created with normalized payload.
  - Response 201: {search_id, normalized_criteria, warnings[], hints[]}
  - Errors:
    - 400 validation.field_required/{field}
    - 400 validation.enum_invalid/{field}
    - 400 validation.mutually_exclusive.amount_and_band
    - 422 conflict.* (as above)
- GET /v1/residential/search/{search_id}
  - Returns stored normalized criteria and status; 404 if not found or not owned by caller.
- Security
  - Ownership: only creator (or org admin) can read a search.
  - Input size limits: JSON body <= 32 KB; strings <= 128 chars.
  - Audit log on create with user_id, ip, ua.

User-facing flows
- Broker requests metadata to render mandatory fields, bands, and presets.
- Broker submits mandatory fields; backend validates and returns normalized_criteria with snapped LTV and hints (e.g., “Typical max LTV 80% for investment condo”).
- Advanced filters optionally added and resubmitted (client may PATCH by re-POSTing; new search_id each time to keep scenarios immutable).

Acceptance criteria
- Mandatory fields enforced; missing any returns 400 with per-field codes.
- LTV 79.6 snaps to 80; 80.5 snaps to 80; 85.1 snaps to 90.
- Docs_type=dscr with occupancy=owner_occupied returns 422 conflict.dscr_occupancy.
- City “LA” with state=CA returns suggestions including “Los Angeles”; invalid city without suggestions returns 422 validation.city_not_found.
- Amount “$1,250,000” parses to 1250000; amount_band {min: 500000, max: 1500000} sets amount_min/max; providing both returns 400.
- Metadata returns advanced=true for borrower_type, product_type, closing_speed; required=true for mandatory set.
- Presets included and expand to valid criteria bundles via metadata.
- Auth required; unauthenticated requests get 401.
- Ownership enforced on GET /search/{id}; cross-tenant access gets 403.

Out of scope
- Actual lender matching, ranking, and result retrieval.
- Scenario saving/cloning beyond returning search_id.
- Commercial search inputs and filters.
- UI progressive disclosure; this is supported via metadata flags only.