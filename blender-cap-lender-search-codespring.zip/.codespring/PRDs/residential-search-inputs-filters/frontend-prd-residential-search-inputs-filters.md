# Frontend PRD: Residential Search Inputs & Filters
**Feature:** Residential Search Inputs & Filters  
**Type:** frontend

## Feature overview
Residential Search Inputs & Filters collects deal parameters for residential scenarios to drive lender matching. It prioritizes fast entry of mandatory criteria with progressive disclosure of advanced options, supports presets and bands, and enforces domain-specific validation to improve match accuracy. Optimized for mobile with sticky Submit, numeric keypads, and accessible controls.

## Scope & behavior
- Audience/permissions
  - Visible to authenticated users with Broker role in Residential mode.
  - Defaults to Residential context; Commercial inputs are out of scope.

- Form structure
  - Section A: Mandatory (always visible)
    - Purpose (Purchase, Refi — Rate/Term, Refi — Cash‑out) with presets as segmented control. Required.
    - Property type (SFR, Condo, Townhome, 2–4 Unit, Multifamily [5+ optional toggle]). Required.
    - State (US state selector; single select). Required.
    - City (typeahead within selected state; optional). Optional.
    - Loan amount (input with bands and free text). Required.
    - Occupancy (Owner‑occupied, Second home, Investment). Required.
    - FICO band (band chips: 760+, 740–759, 720–739, 700–719, 660–699, 620–659, <620, No minimum). Required.
    - LTV (percentage input with snap). Required.
    - Documentation type (Full, Bank statements, Stated, No‑doc, DSCR). Required.
  - Section B: Advanced (collapsed by default; toggled via “Advanced filters”)
    - Borrower type (Individual, LLC, Corp, Trust, Foreign National).
    - Product type (Fixed 30/20/15, ARM 5/6, 7/6, 10/6, Interest‑Only, Bridge, HELOC).
    - Closing speed (Need term: ≤7d, ≤14d, ≤21d, Flexible).

- Presets and bands
  - Purpose as segmented presets autoselects common defaults for LTV hint and Docs helper text; does not overwrite explicit user entries.
  - Loan amount supports:
    - Band chips: <$250k, $250–500k, $500–1M, $1–2M, $2–5M, $5M+.
    - Free‑text currency input; selecting a band fills min/max but allows override.
  - FICO is selected via bands only (no free‑text). Include “No minimum.”
  - LTV input snaps to nearest of [50, 60, 70, 80, 90] on blur; users can set any 0–100 within validation.

- Inline hints
  - Contextual helper text beneath fields:
    - Property type: show typical LTV caps and FICO mins for the selected subtype (static copy from content config).
    - Docs: brief explanations and common use cases (e.g., “DSCR: investment properties only”).

- Validation and errors
  - On blur validation; blocking errors shown inline; Submit performs full validation.
  - Loan amount: positive number; min $25,000; max $50,000,000; format to currency with commas.
  - LTV: 0–100 inclusive; display %; snap behavior as above; show error if outside range.
  - FICO: must pick one band; if “No minimum” selected, disable FICO‑dependent hints.
  - State: required; City optional but constrained to selected state.
  - Docs: selection required; if DSCR chosen and Occupancy is Owner‑occupied/Second home, show non‑blocking warning and allow continue.
  - Multifamily (5+) visibility is controlled by a toggle “Include 5+ units”; if off, 5+ option hidden and deselected.

- Interactions
  - Search is only executed on Submit; no auto‑query while typing.
  - Sticky Submit bar on mobile (<=768px): contains summary count of selected filters and primary “Find Lenders.”
  - Clear All resets both sections; confirms if any mandatory has input.

- Component/UX specifics
  - Inputs use accessible labels, placeholders, and helper text.
  - Filter summary chips appear above the form after first input; removable chips mirror the field state.
  - Advanced section state persists across sessions per user (local storage).

- Responsive behavior
  - Mobile: single‑column layout; numeric keypad for amount and LTV (inputmode=numeric, pattern to allow decimals).
  - Desktop/tablet: two‑column for Mandatory; Advanced single‑column accordion.

- Accessibility
  - All interactive elements keyboard navigable; visible focus states.
  - Errors announced via ARIA live region; error text tied to inputs via aria‑describedby.
  - Contrast meets WCAG AA; touch targets ≥44px.

## User-facing flows
- Happy path
  1) User selects Purpose preset.
  2) Chooses Property type, State; optionally enters City.
  3) Enters Loan amount (band or free‑text); sets Occupancy.
  4) Selects FICO band; enters LTV (snaps on blur).
  5) Selects Docs type.
  6) Optionally expands Advanced, sets Borrower/Product/Closing speed.
  7) Taps “Find Lenders” (sticky on mobile) → navigates to Results with persisted criteria.

- Edge cases
  - Missing mandatory: Submit disabled until all required fields valid; on click (desktop), scroll to first error and focus it.
  - DSCR + Owner‑occupied: show warning “DSCR typically for investment properties” with “Proceed anyway.”
  - City typed before State: City input disabled until State selected; helper prompts to select State first.
  - Switching Property type clears incompatible Advanced selections (e.g., Bridge only if Product type supports); show toast “Cleared incompatible selections.”

## Acceptance criteria
- Mandatory fields cannot be empty at submit; Submit disabled until valid.
- Loan amount accepts both band selection and manual entry; manual entry overrides band and formats as $X,XXX,XXX.
- LTV input snaps to nearest 50/60/70/80/90 on blur and remains user‑editable; accepts any 0–100 value.
- FICO can only be set via provided bands, including “No minimum.”
- State is required; City list is filtered by selected State and disabled otherwise.
- Docs: selecting any option is required; DSCR + non‑investment shows non‑blocking warning.
- Advanced section is collapsed by default and persists last open/closed state per user.
- Sticky Submit bar appears on mobile with filter count and primary action; not shown on desktop.
- Inline hints render based on current selections and update in real time.
- All errors are inline, descriptive, and announced to screen readers.
- Clear All resets form and removes summary chips; confirmation shown if any field had input.

## Out of scope
- Search execution, scoring, results list, and lender explanations.
- Scenario save/clone, comparisons, and tracking.
- Multi‑state selection, geolocation, and map inputs.
- Non‑US locations, commercial property types, and income/DTI calculators.