# Database PRD: Residential Search Inputs & Filters
**Feature:** Residential Search Inputs & Filters  
**Type:** database

## Feature Scope
Stores residential search inputs, selectable filter vocabularies, snapping bands (FICO, LTV, Amount), optional presets, and inline hint guidelines per property type. Supports progressive disclosure (mandatory vs optional), validation constraints, and fast lookup for the matching engine.

## Entities & Relationships
- residential_search references lookup vocabularies: purposes, property_types, occupancy_types, documentation_types, fico_bands, amount_bands, ltv_steps, borrower_types, product_types, closing_speed_options, states.
- residential_search_preset mirrors search fields to allow saved defaults; residential_search optionally references a preset used.
- property_type_guidelines provides inline hints (typical LTV caps, min FICO) per property type.

## Constraints & Validation
- Mandatory on residential_search: purpose_id, property_type_id, state_code, loan_amount (>0), occupancy_type_id, fico_band_id, ltv_percent (0–100), documentation_type_id.
- Optional: borrower_type_id, product_type_id, closing_speed_option_id, city, amount_band_id, preset_id.
- ltv_percent: INT 0–100; enforce CHECK (0 <= ltv_percent AND ltv_percent <= 100). Snap to nearest ltv_steps.ltv when writing; store exact INT.
- fico_bands: define contiguous or labeled bands; ensure no overlaps at data-management time; allow a special band for "No minimum" via includes_no_min = TRUE with NULL min/max.
- amount_bands: min_amount/max_amount define bands; allow open-ended with NULL min or max; loan_amount must be positive NUMERIC(14,2).
- state_code must exist in states; city is free text (normalized casing on write; index not required here).
- documentation_types restricted to listed codes: full, bank_stmt, stated, no_doc, dscr (loaded as seed data).
- property_types restricted to: sfr, condo, townhome, two_to_four, multifamily_5_plus (5+ optional; can be inactive to hide).

## Indexing
- residential_search: BTREE indexes on (user_id, created_at DESC), purpose_id, property_type_id, state_code, fico_band_id, documentation_type_id, ltv_percent, loan_amount to support matching engine filters.
- Lookup tables: PK/unique on code/ltv; is_active + display_order for efficient ordered retrieval.
- Foreign key indexes on all *_id fields.

## Data Integrity
- Soft vocab governance via is_active and display_order across lookup tables; do not delete in use.
- Residential-only scope ensured by residential_only = TRUE on property_types.
- property_type_guidelines is advisory; not enforced by matching logic but available for UI hints.

## Progressive Disclosure & Presets
- residential_search.used_advanced flags whether optional fields were revealed/used.
- residential_search_preset supports partial presets (nullable fields). A user can mark one as is_default; enforce at app level one default per user.
