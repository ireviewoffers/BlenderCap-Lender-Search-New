# Frontend PRD: Advanced Deal Filters
**Feature:** Advanced Deal Filters  
**Type:** frontend

# Advanced Deal Filters

## Feature overview
Advanced Deal Filters let brokers narrow lender matches by key underwriting criteria before viewing results. Filters are tailored to Residential vs Commercial scenarios, with responsive UI, clear defaults, and guardrails for valid value ranges. The goal is fast, accurate refinement with minimal friction on mobile and desktop.

## Scope & behavior
- Placement
  - Desktop: collapsible left sidebar on the Lender Search results page.
  - Mobile: Filter button in header opens a full-height bottom sheet modal with Apply and Reset actions fixed to the footer.

- Filter set (all optional unless noted)
  - Deal context: Residential or Commercial (inherited from scenario; not editable here).
  - Loan Purpose (single-select): Purchase, Rate/Term Refi, Cash-Out Refi, Bridge, Construction.
  - Loan Amount (range): Min and Max currency inputs with thousand separators and USD fixed; allowed 10,000–200,000,000; step 1,000.
  - Property Type (multi-select; options depend on context)
    - Residential: SFR, Condo, Townhome, 2–4 Unit, Condo-tel, Manufactured, Co-op.
    - Commercial: Multifamily (5+), Mixed-Use, Retail, Office, Industrial, Hospitality, Self-Storage, Land, Mobile Home Park, Special Purpose.
  - Occupancy (single-select; Residential: Primary, Second Home, Investment; Commercial: Owner-User, Investment).
  - Location (multi-select): by State (US states/territories); optional ZIP include field (comma/space separated; max 50 ZIPs). State and ZIP can co-exist; if no state provided but ZIPs present, infer state per ZIP.
  - FICO (min score): numeric input 300–850; whole numbers only.
  - LTV (max LTV): numeric input 0–100%; whole numbers; displayed with %.
  - Docs Type (multi-select): Full Doc, Bank Statements, DSCR/No Ratio, Stated, No-Doc, Lite Doc.
  - Borrower Type (multi-select): Individual, LLC, Corporation, Trust, Partnership, Foreign National.
  - Product Type (multi-select): Fixed, ARM, Interest-Only, DSCR, Bridge, Construction, SBA, Non-Recourse.
  - Closing Speed (max days): numeric input 5–365.

- UI controls and interactions
  - Each filter has a labeled control with helper text for range constraints.
  - Multi-select presented as searchable dropdown with checkboxes and selected-item chips.
  - Range fields use paired inputs; invalid states show inline messages.
  - Summary chips appear above results showing active filters (e.g., “LTV ≤ 70%”, “CA, TX, 94105”). Each chip has an X to remove only that criterion.
  - “Reset all” clears all filters to defaults (no filters applied).
  - “Apply” triggers a results refresh; on desktop, an “X matches” preview count updates as filters change (debounced 400 ms) before Apply.
  - Loading state: skeleton cards replace results; filter panel remains interactive.
  - Empty state: if no matches, show message with “Clear filters” quick action.

- Validations and error handling
  - Loan Amount: Min cannot exceed Max; if violated, show “Min must be ≤ Max” and disable Apply.
  - FICO, LTV, Closing Speed: values outside bounds highlight field with message; Apply disabled until corrected.
  - ZIP format: 5-digit only; invalid entries are highlighted and ignored on Apply with toast “Invalid ZIPs removed.”
  - Max selections: none, except ZIP limit (50); when exceeded, show inline error and ignore extras.

- State, persistence, and shareability
  - Active filters persist in URL query parameters and restore on load.
  - Last-used filters per scenario type cached in local storage and preloaded when no URL params exist.
  - Clearing filters removes related URL params.

- Permissions
  - Available to authenticated brokers. Unauthenticated users see a disabled Filter button with tooltip “Sign in to refine results.”

- Accessibility
  - All controls keyboard navigable; focus trap in mobile modal; ARIA labels on inputs; descriptive errors with role=alert; 4.5:1 contrast minimum.

## User-facing flows
- Open filters
  - Desktop: Click “Filters” to expand sidebar; icon badge shows active filter count.
  - Mobile: Tap “Filters” to open modal; header shows active filter count.

- Adjust filters
  - Select values; preview match count updates after 400 ms idle.
  - Errors shown inline immediately upon blur or Apply.

- Apply / Reset
  - Tap/click Apply: results refresh; URL updates to reflect filters.
  - Tap Reset all: clear filters, refresh results, remove filter query params.

- Remove individual filter
  - Click X on a summary chip; results refresh, URL updates.

- Edge cases
  - Switching scenario context elsewhere (Residential/Commercial) auto-adjusts property/occupancy options and drops incompatible selections with toast “Some filters were cleared due to scenario change.”

## Acceptance criteria
- Filter controls and option sets match Scope & behavior, with context-specific options.
- Debounced preview match count updates within 400–800 ms of last change; Apply triggers fetch immediately.
- Apply disabled when any validation error exists.
- URL reflects active filters; reloading the page with those params restores identical state and results.
- Summary chips accurately mirror active filters and support single-chip removal.
- Mobile modal uses focus trap; Escape/Back closes without applying; “Apply” commits; “Reset all” clears.
- Empty results state and “Clear filters” action appear when result count = 0.
- ZIP inputs accept only valid 5-digit codes; invalid entries are highlighted and excluded with toast.
- Performance: interactions remain responsive; typing latency < 50 ms; applying filters triggers visible skeletons within 150 ms.

## Out of scope
- Creating/saving named filter presets.
- Advanced geospatial radius search or map-based filtering.
- Sorting or pinning lenders.
- Editing scenario core data (income, DSCR, NOI, etc.).
- Admin configuration of option lists via UI.