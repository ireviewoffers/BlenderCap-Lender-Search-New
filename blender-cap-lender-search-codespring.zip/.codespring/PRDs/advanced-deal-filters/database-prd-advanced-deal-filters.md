# Database PRD: Advanced Deal Filters
**Feature:** Advanced Deal Filters  
**Type:** database

## Advanced Deal Filters — Database Scope
Supports dynamic, normalized filter facets for deal searches and saved presets per user. Dimensions include: loan purpose, amount, property type, occupancy, location, FICO, LTV, docs type, borrower type, product type, closing speed.

### Entities & Relationships
- filter_dimensions defines each facet (data type, multi-select behavior, allowed value kinds).
- filter_options stores hierarchical categorical values (e.g., Property Type > Multifamily).
- geo_regions normalizes selectable locations (country/state/county/city or custom regions).
- saved_filter_sets stores user-defined presets.
- saved_filter_set_items stores selected values per dimension within a preset. An item is one of: categorical (option_id), range (min/max), or location (region_id).

### Constraints & Behaviors
- A saved_filter_set_item must reference exactly one of option_id, region_id, or a min/max range depending on the parent dimension.input_kind.
- Range bounds are optional; null implies open-ended. Inclusivity flags define boundary semantics.
- Dimension-level typing enforces value correctness (enum/range/geo). For range, numeric_type determines precision (INT for FICO/closing_speed; DECIMAL for amount/LTV).
- Hierarchical options (filter_options.parent_option_id) allow roll-ups; selecting a parent implies all descendants at query time.
- geo_regions supports hierarchy; selecting a parent region (e.g., state) implies all children regions (e.g., counties/cities) when executing filters.
- Duplicate prevention: within a saved_filter_set, (dimension_id, option_id/region_id/range signature) must be unique.
- Soft limits: max 50 items per saved_filter_set to constrain query complexity (enforced at application layer, but indexed to support validation queries).

### Indexing
- filter_dimensions.name unique; frequent lookups by name.
- filter_options(dimension_id, slug) unique; btree on (dimension_id, parent_option_id) for hierarchy traversals.
- geo_regions(type, code) unique; btree on parent_region_id.
- saved_filter_sets(user_id, is_default desc, updated_at desc) for quick retrieval of active presets.
- saved_filter_set_items(saved_filter_set_id, dimension_id) and partial indexes per value kind to accelerate query assembly.

### Data Seeds (examples)
- Dimensions: loan_purpose(enum), loan_amount(range, DECIMAL), property_type(enum, hierarchical), occupancy(enum), location(geo), fico(range, INT), ltv(range, DECIMAL), docs_type(enum), borrower_type(enum), product_type(enum), closing_speed_days(range, INT).
- Options: e.g., property_type: residential, multifamily, 1-4_unit, 5+_units; occupancy: owner_occupied, non_owner, investment; docs_type: full_doc, bank_statements, DSCR.

### Security & Integrity
- saved_filter_sets.user_id references users (external table). Only owner can mutate.
- Cascade deletes from saved_filter_sets to saved_filter_set_items. Prevent deletes of core dimensions/options if referenced (restrict).