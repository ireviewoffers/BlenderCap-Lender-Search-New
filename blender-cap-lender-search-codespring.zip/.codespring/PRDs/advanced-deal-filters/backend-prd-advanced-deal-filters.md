# Backend PRD: Advanced Deal Filters
**Feature:** Advanced Deal Filters  
**Type:** backend

Feature overview
Advanced Deal Filters enable brokers to refine lender matches for a given loan scenario using precise underwriting attributes (loan purpose, amount, property type, occupancy, geography, FICO, LTV, docs type, borrower type, product type, closing speed). Filters act as hard constraints on the candidate lender universe before scoring/ranking, reducing noise and improving relevance and explainability.

Scope & behavior
- Audience/permissions:
  - Authenticated brokers (residential/commercial) can search with filters.
  - Lender/partner accounts may query only their own programs for preview (flag limited_to_account=true).
  - Role-based access enforced via JWT; scenario access limited to owner/org.
- Filtering semantics:
  - All provided filters are ANDed.
  - Ranges: numeric fields support closed intervals [min, max]. Omitted bound is unbounded on that side.
  - Enums: only allowed values accepted; case-insensitive; arrays are ORed within the field.
  - Location: supports country, state, county, MSA, or ZIP. Most specific provided wins; fallback to broader if specific not supported by program data.
  - Closing speed: interprets as required max days-to-close; match programs with max_close_days <= requested.
  - Amount: interpreted as requested loan amount; match programs whose min_amount <= amount <= max_amount.
  - LTV: requested max LTV; match programs with max_ltv >= requested.
  - FICO: requested min FICO; match programs with min_fico <= requested_min_fico.
  - Occupancy, property_type, docs_type, borrower_type, loan_purpose, product_type must be explicitly supported by program.
- Validation:
  - amount > 0; <= 500,000,000.
  - fico_min in [300, 850].
  - ltv_max in (0, 100], precision 0.01.
  - closing_speed_days in [1, 120].
  - Enums: loan_purpose {purchase, rate_term_refi, cash_out_refi, construction, bridge}, property_type varies by channel:
    - Residential: {SFR, condo, townhome, 2-4_unit, 5+_multifamily (if applicable), mixed_use_residential}
    - Commercial: {multifamily, office, retail, industrial, mixed_use, hospitality, land, self_storage, special_purpose}
  - occupancy {owner_occupied, non_owner, second_home, investor} (validated by channel).
  - docs_type {full_doc, bank_statement, DSCR, no_doc, stated, asset_depletion}.
  - borrower_type {individual, LLC, corp, trust, foreign_national}.
  - product_type {fixed, ARM, IO_fixed, IO_ARM, bridge, construction_to_perm, DSCR}.
  - If scenario_id provided, channel (Residential/Commercial) inferred and cross-validates property/occupancy/docs types; reject incompatible combos (422).
  - Reject conflicting ranges where min > max (422).
- Behavior with scenario:
  - If scenario_id present, base constraints (amount, location, LTV, FICO, purpose, property) are seeded from scenario; explicit filters override.
  - Filters are applied pre-scoring; resulting set is then scored/ranked by existing matching engine. Response includes reason codes for exclusion count, and top-N with explanations.
- Performance:
  - Return first page within p95 <= 600ms for result sets <= 10k programs.
  - Pagination required; default limit=25, max=100. Cursor-based pagination.
  - Index program attributes (amount bounds, geography, enums, numeric thresholds). Cache identical queries per org for 60s.
- Security:
  - Input sanitized; prevent SQL injection with parameterization.
  - DoS protection: 10 requests/sec/user, burst 30; 429 on exceed.

User-facing flows
- Broker filters lender matches for a scenario:
  - POST with scenario_id and filters; receives ranked matches, total_count, and applied_filters echo.
  - Edge cases: no matches → 200 with empty array and message “No programs match filters.”; overly broad → capped by pagination; invalid enum → 422 with enum list; conflicting bounds → 422.
- Partner previews their own programs:
  - Include limited_to_account=true to constrain to caller’s org programs.

API contract
- POST /v1/matches/search
  - Auth: Bearer JWT
  - Body:
    {
      "scenario_id": "uuid-optional",
      "limited_to_account": false,
      "filters": {
        "loan_purpose": ["purchase","cash_out_refi"],
        "amount": { "value": 450000 },
        "property_type": ["SFR"],
        "occupancy": ["investor"],
        "location": { "country": "US", "state": "CA", "zip": "90012" },
        "fico_min": 700,
        "ltv_max": 75.0,
        "docs_type": ["DSCR","full_doc"],
        "borrower_type": ["LLC","individual"],
        "product_type": ["DSCR","fixed"],
        "closing_speed_days": 21
      },
      "sort": { "by": "score", "dir": "desc" },
      "page": { "limit": 25, "cursor": "opaque-optional" }
    }
  - 200 Response:
    {
      "applied_filters": { ...resolved values... },
      "total_count": 123,
      "next_cursor": "opaque-or-null",
      "matches": [
        {
          "program_id": "uuid",
          "lender_id": "uuid",
          "score": 0.87,
          "explanations": ["Supports DSCR for SFR investor", "Max LTV 80% >= requested 75%"],
          "key_terms": {
            "min_amount": 100000,
            "max_amount": 2000000,
            "max_ltv": 80,
            "min_fico": 680,
            "max_close_days": 21
          }
        }
      ],
      "excluded_counts": {
        "amount_out_of_bounds": 421,
        "ltv_too_high": 133,
        "fico_too_low": 78,
        "unsupported_property": 55,
        "geography_not_approved": 22,
        "other": 10
      },
      "message": "string-optional"
    }
  - 401/403 on auth/permission failure; 422 on validation errors with details; 429 on rate limit.

Acceptance criteria
- All specified filters are enforced as hard constraints prior to scoring.
- Validation rejects invalid enums, incompatible channel-property combinations, and contradictory ranges with 422 and field-level errors.
- Location filter supports ZIP, county FIPS, state, and country; matching honors program coverage hierarchies.
- Scenario seeding works; explicit filters override scenario values.
- Pagination via cursor works; next_cursor is null when no further pages.
- Performance: p95 latency <= 600ms for typical queries; 95% of requests use indexed plans.
- Security: only authorized users can search; lender preview constrained to caller’s org when limited_to_account=true.
- Response includes excluded_counts and explanations for top matches.

Out of scope
- UI components for filter selection.
- Creating/editing lender programs or scenarios.
- Faceted counts per filter value.
- Exporting, saving, or sharing filter presets.
- Real-time notifications or webhooks.