# Backend PRD: Commercial Path — Filter Pack
**Feature:** Commercial Path — Filter Pack  
**Type:** backend

Feature overview
Commercial Path — Filter Pack provides a validated input schema and APIs to filter commercial lending matches by property type, loan size bands, borrower/entity profile, documentation type, requested leverage (LTV/LTC), and desired closing speed. It standardizes inputs for the matching engine to reliably narrow lender candidates and improve ranking relevance and explanations for commercial scenarios.

Scope & behavior
- Authentication and roles
  - Requires authenticated user with role: broker (commercial or residential with commercial access). 401 if missing, 403 if role not permitted.
- Supported filters (all optional unless marked required)
  - property_type (required): enum [office, retail, industrial, hospitality, mixed_use, land]
    - If mixed_use, optional dominant_use enum [office, retail, residential, hospitality, industrial] and dominant_use_pct (integer 1–100).
  - loan_size_bands (required): multi-select enum mapped to USD ranges
    - small: 0.25M–1M; mid: >1M–5M; large: >5M–20M; xl: >20M
    - Backend expands to min_loan_amount and max_loan_amount; overlapping bands union the ranges.
    - Optional loan_amount_exact (USD) mutually exclusive with bands; if provided, backend derives band(s).
  - borrowing_entity_type: enum [individual, llc, lp, corporation, trust, s_corp, c_corp]
  - is_foreign_national: boolean; if true, optional country_iso2 (A–Z{2})
  - docs_type: multi-select enum [full_doc, limited_doc, no_doc, dscr]
  - ltv_request_pct: number 0–100 with up to 2 decimals
  - ltc_request_pct: number 0–100 with up to 2 decimals (used if construction/rehab scenarios; otherwise optional)
  - desired_days_to_close: integer 1–365
    - Internally bucketed: rush (<=15), standard (16–45), flexible (>45)
- Validation
  - At least one of {loan_size_bands, loan_amount_exact} is required.
  - property_type required; if mixed_use and dominant_use_pct present, must be 1–100.
  - loan_amount_exact must be >= 250,000 USD and <= 250,000,000 USD.
  - Mutually exclusive: loan_size_bands and loan_amount_exact. 422 if both supplied.
  - ltv_request_pct and ltc_request_pct independent; values >100 or <0 rejected (422).
  - country_iso2 must be valid ISO-3166-1 alpha-2 if provided.
- Matching behavior impacts
  - Filters act as hard constraints unless marked as preference:
    - Hard: property_type, loan amount range (from bands/derived), entity/foreign national compatibility.
    - Soft: docs_type, desired_days_to_close bucket, LTV/LTC (treated as min/max checks against lender caps/floors; failing becomes exclude if lender states hard limit).
  - Engine returns lenders whose underwriting rules intersect with constraints and ranks by confidence; this feature does not alter scoring algorithm, only inputs and constraint set.
- Pagination and limits
  - Default page_size=25, max=100, page>=1. Max total results returned=200 (cap).
- Performance SLAs
  - GET options P95 <= 150ms; POST search P95 <= 800ms for page_size<=25. Index query-only; no full scans over >50k lenders.

User-facing flows
- Broker opens Commercial path: client requests GET /v1/commercial/filters/options to render enums, bands, and defaults.
- Broker submits filter pack: client sends POST /v1/commercial/search with filter payload; server validates, normalizes ranges, applies constraints, returns paginated lender matches and applied_filters echo.
- Edge cases
  - No matches: 200 with empty results[], total=0.
  - Overlapping bands: unioned into a single range.
  - Mixed-use provided without dominant_use: accept; engine uses generic mixed_use rules.
  - Foreign national true with unsupported entity by lender: excluded.

API endpoints
- GET /v1/commercial/filters/options
  - Auth: required
  - Response 200
    - property_types: [...]
    - loan_size_bands: [{code, min_usd, max_usd|null}]
    - borrowing_entity_types: [...]
    - docs_types: [...]
    - closing_speed_buckets: [{code, min_days, max_days}]
    - validations: {min_loan_usd, max_loan_usd, pct_min, pct_max}
- POST /v1/commercial/search
  - Auth: required
  - Request body
    - property_type: string enum
    - mixed_use_meta?: {dominant_use?: enum, dominant_use_pct?: integer}
    - loan_size_bands?: string[]
    - loan_amount_exact_usd?: number
    - borrowing_entity_type?: string enum
    - is_foreign_national?: boolean
    - country_iso2?: string
    - docs_type?: string[]
    - ltv_request_pct?: number
    - ltc_request_pct?: number
    - desired_days_to_close?: integer
    - page?: integer, page_size?: integer, sort?: enum [confidence_desc, speed_asc]
  - Responses
    - 200: {results: [{lender_id, name, confidence_score, reasons_summary[]}], total, page, page_size, applied_filters:{...}}
    - 400: malformed JSON
    - 401/403: auth errors
    - 422: validation errors [{field, code, message}]
    - 429, 500: standard

Security and audit
- JWT bearer; scope: search:commercial.
- Log search requests (user_id, timestamp, normalized filters, result_count); exclude PII beyond country_iso2.

Acceptance criteria
- GET options returns stable enums and band definitions matching this spec.
- POST search enforces required fields and mutual exclusivity rules; 422 on violations with precise field-level errors.
- Loan size bands correctly map to USD ranges; overlapping selections unioned; exact amount maps to correct band.
- Hard constraints exclude ineligible lenders; soft constraints influence ranking but not exclusion unless lender rule is hard limit.
- Mixed-use meta accepted and does not error when omitted.
- Foreign national filter excludes lenders not supporting it; country_iso2 ignored if is_foreign_national=false.
- Pagination and caps function; default page_size=25, max=100; total capped at 200.
- P95 latency meets SLAs in staging with dataset of >=10k lenders.
- All endpoints require auth and return 401/403 appropriately.

Out of scope
- Residential path filters, construction-specific fields, scenario persistence, cloning, comparisons, PDF/email generation, lender-side rule authoring, front-end UI rendering, and scoring algorithm changes.