# Frontend PRD: Commercial Path — Filter Pack
**Feature:** Commercial Path — Filter Pack  
**Type:** frontend

# Commercial Path — Filter Pack

## Feature overview
A responsive filter pack for the Commercial path that lets brokers narrow lender matches by property type, loan size band, entity/foreign national status, documentation type, LTV/LTC, and closing speed. Filters update lender results in real time with clear, selectable presets and numeric ranges. Designed for quick screening on mobile and desktop with accessible controls and sensible defaults.

## Scope & behavior
- Availability
  - Visible only in Commercial path after authentication (broker roles).
  - Shown as a left sidebar on desktop/tablet; as a top “Filters” button opening a full-screen sheet/drawer on mobile.

- Filter controls
  - Property Type (required; multi-select): Office, Retail, Industrial, Hospitality, Mixed-Use, Land.
    - At least one must be selected; if user attempts to run search with none, show inline error and disable Apply.
  - Loan Size Band: preset chips (e.g., 0–$1M, $1–$5M, $5–$25M, $25M+) plus Custom range (Min/Max currency inputs).
    - Currency inputs accept integers only, min 0, Max ≥ Min; thousands separators displayed; non-numeric rejected with inline error.
  - Entity Type: multi-select chips: Individual, LLC, LP, Corp, Trust. Default: Any.
  - Foreign National: radio group: Any (default), Yes, No.
  - Documentation Type: multi-select chips: Full Doc, Lite/Alt-Doc, Bank Statements, DSCR, Stated/No-Doc. Default: Any.
  - Leverage Metric: segmented control to choose LTV or LTC.
    - Range slider (0–100 for LTV, 0–95 for LTC), with numeric Min/Max boxes; Max ≥ Min enforced.
    - Inputs limited to whole percents; out-of-bounds values clamped and error messaged.
  - Closing Speed: preset chips (ASAP, ≤14 days, 15–30, 31–60, >60) plus Custom days (numeric input 1–365).
    - If both preset and Custom are used, Custom overrides.

- Interactions
  - Results update: apply-on-change with 300 ms debounce on desktop; in mobile drawer, changes stage locally and apply on “Show Results” CTA.
  - Active filter count badge displayed on the Filters button (mobile) and in sidebar header (desktop).
  - Clear All resets all filters to defaults (Property Type remains last valid selection or prompts user to reselect).
  - Incompatible states show no-results message in results area with “Clear conflicting filters” inline action (retains Property Type).

- Validation & errors
  - Inline, field-level messages; prevent apply when errors exist.
  - Accessibility: all controls keyboard-navigable, ARIA labels, slider has numeric input alternative, 4.5:1 contrast.

- Persistence & deep linking
  - Persist selections per scenario in local state and server-side when scenario is saved.
  - Reflect filters in URL query params for share/deep-link; loading a link hydrates controls accordingly.

## User-facing flows
- Desktop quick filter
  1. User checks 2 property types (Retail, Industrial).
  2. Selects $1–$5M preset; moves LTV slider to 60–70%.
  3. Results update with loading shimmer then refreshed matches; active count shows “3”.
  4. Clicks Clear All; property type prompt appears; must reselect at least one to continue.

- Mobile filter drawer
  1. Tap Filters; full-screen sheet opens with sections accordionized.
  2. Choose Hospitality; set Closing Speed to ≤14 days; add Foreign National = Yes.
  3. Tap Show Results; drawer closes; results update.
  4. Tap Filters; Clear All; warning indicates Property Type required; Hospitality remains selected or requires reselection if previously cleared.

- Edge cases
  - Custom Loan Size Min > Max: show error, disable Apply/Show Results.
  - LTV set to 0–0: treated as 0% exactly; allowed.
  - Selecting Land auto-shows tooltip: “Some lenders use LTC; switch metric if needed” (no auto-switch).

## Acceptance criteria
- Property Type is required; attempting to apply with none selected displays inline error and blocks apply.
- All presets/chips are toggleable; multi-select persists across sessions for a saved scenario.
- Debounced updates on desktop; mobile applies only on “Show Results.”
- URL reflects all active filters; reloading the URL restores identical UI state.
- Numeric inputs reject non-numeric characters and display human-formatted values on blur.
- LTV/LTC sliders constrain to allowed ranges; Min cannot exceed Max; errors shown when violated.
- Clear All resets every filter to default and triggers results refresh; no JS errors.
- Active filter count accurately reflects number of non-default filters.
- Accessibility checks: focus order logical, sliders operable via keyboard, labels announced by screen readers.

## Out of scope
- Editing lender-side eligibility rules.
- Saving filter presets named by users.
- Cross-path filters (Residential) and scenario details entry UI.
- Backend matching logic changes; this feature only controls inputs to the existing engine.