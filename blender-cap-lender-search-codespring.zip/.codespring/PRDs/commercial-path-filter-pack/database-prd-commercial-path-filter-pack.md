# Database PRD: Commercial Path — Filter Pack
**Feature:** Commercial Path — Filter Pack  
**Type:** database

## Commercial Path — Filter Pack: Database Schema

Supports configuring and applying lender eligibility filters for commercial scenarios. Scope covers filter taxonomies (property type, docs type, borrower entity/foreign national, loan size bands, LTV/LTC, closing speed), lender guideline mappings, and per-scenario filter selections for matching and explanations.

### Entities & Relationships
- Reference taxonomies
  - commercial_property_type, commercial_doc_type, borrower_entity_type, loan_size_band, closing_speed_option
- Lender guideline constraints (per lender, commercial path)
  - lender_commercial_criteria (scalar constraints: loan size, LTV/LTC, foreign national, closing speed)
  - lender_allowed_property_type, lender_allowed_doc_type, lender_allowed_entity_type (many-to-many allowlists)
- Scenario-level selected filters (commercial only)
  - commercial_filter_selection (one row per scenario; references taxonomy rows)

### Constraints & Behaviors
- Property type, doc type, and entity type allowlists are positive lists; absence means not eligible for that type.
- Loan size bands are inclusive ranges [min_amount, max_amount]. Enforce non-overlap within the same currency via a uniqueness label; validation at write-time should ensure no overlapping bands per currency.
- LTV/LTC stored as percentages (e.g., 65.00). If a lender has both, both can be set; matching engine should use relevant metric per scenario context (stabilized vs construction). Null means not offered.
- Closing speed
  - lender_commercial_criteria.min_days_to_close is an INT lower bound under normal processing.
  - closing_speed_option defines discrete UX buckets; matching is satisfied if min_days_to_close <= option.max_days.
- Foreign national
  - foreign_national_allowed = TRUE means lender will consider foreign nationals; FALSE means not allowed.
- Entity types: allowlist must include the borrower’s declared entity type or the scenario is filtered out.
- Scenario selection stores explicit user-selected filters; null fields mean “no preference” except property_type_id and target_loan_amount which should be present in commercial flow.

### Indexing
- lender_commercial_criteria: (lender_id) PK; btree on (min_loan_amount, max_loan_amount), (min_days_to_close), (max_ltv_percent), (max_ltc_percent), (foreign_national_allowed)
- Mapping tables: composite unique (lender_id, *_id); btree on (*_id) for reverse lookups.
- Reference tables: unique codes; loan_size_band btree on (currency_code, min_amount, max_amount).
- commercial_filter_selection: index on (scenario_id), (property_type_id), (doc_type_id), (borrower_entity_type_id), (desired_closing_days).

### Data Integrity
- All reference rows are immutable after use; use is_active flags to soft-deprecate.
- Amounts in INT represent minor units (e.g., cents) to avoid rounding errors. Percentages use NUMERIC(5,2).
- Timestamps captured for auditing; soft deletes avoided for criteria to maintain explainability history.
