# Backend PRD: Loan Scenario Search Form
**Feature:** Loan Scenario Search Form  
**Type:** backend

Feature overview
- Collects all data required to qualify a residential or commercial loan scenario, validates it, persists it, and triggers lender-matching.
- Supports draft saving, partial updates, and final submission with strict validation. Computes derived metrics (e.g., LTV, LTC, DSCR inputs) server-side to ensure consistency.

Scope & behavior
- Roles/permissions:
  - BROKER (authenticated) can create, update, submit, and read own scenarios.
  - ADMIN can read/update any scenario.
  - LENDER cannot create/submit scenarios.
- Scenario states: draft (partial allowed), submitted (immutable core fields), archived (read-only; not matchable).
- Data model (top-level scenario fields)
  - channel: enum [residential, commercial] REQUIRED
  - property: { address_line1, city, state(US 2-letter), zip(5-digit), county?, msa_code? }
  - property_type: enum (by channel)
    - residential: [SFR, Condo, 2-4 Unit, 5+ Unit, Townhome]
    - commercial: [Multifamily, Mixed-Use, Retail, Office, Industrial, Warehouse, Hotel, Land, Self-Storage, Special-Purpose]
  - occupancy: enum (residential: [Owner-Occ, Non-Owner], commercial: [Investment, Owner-User])
  - units: int >= 1 (required for 2+ unit and any commercial/multifamily)
  - loan_purpose: enum [Purchase, Rate/Term Refi, Cash-Out Refi, Construction, Bridge, Fix-and-Flip]
  - loan_amount: currency > 0
  - valuation: { purchase_price?, appraised_value? } at least one required; for purchase, purchase_price required
  - rehab_budget? currency >=0 (required for Fix-and-Flip or Construction)
  - as_is_value?, after_repair_value? (ARV) for Fix-and-Flip/Bridge optional; at least one if rehab_budget provided
  - income_docs: enum [Full-Doc, Bank Statements, DSCR, No-Doc, Lite-Doc] (by channel; DSCR allowed for res non-owner and commercial)
  - borrower: { entity_type [Individual, LLC, Corp, Trust], credit_score (300–850)?, dti? (0–100, residential only), experience_years? (0–50), bankruptcies_7yrs?: boolean, foreclosures_7yrs?: boolean }
  - loan_terms_pref: { rate_type [Fixed, ARM], interest_only?: boolean, amort_term_months? [120–480], prepay_penalty_ok?: boolean, closing_timeline_days? (1–365) }
  - rental_income?: number (monthly), noi_annual?: currency (commercial)
  - taxes_insurance_hoa_monthly?: number >=0
  - existing_loan_payoff?: currency >=0 (refi only)
  - constraints: { max_points?: number >=0, max_ltv?: number (0–150), min_dscr?: number (0.1–5) }
  - notes?: string (2,000 chars max; no PII like SSN)
- Derived fields (computed, not accepted from client on submit):
  - ltv = loan_amount / max(appraised_value, purchase_price if purchase)
  - ltc (if rehab/construction) = loan_amount / (purchase_price + rehab_budget)
  - est_pitia_monthly if taxes/ins/hoa provided (principal/interest not computed here)
- Validation rules
  - Required fields vary by channel/purpose; backend enforces conditional requirements.
  - Geography: state must be in allowed list; zip must be 5 numeric.
  - Ranges: loan_amount 10,000–100,000,000; ltv <= 1.5; ltc <= 2.0; min_dscr >= 0.1; dti <= 80; credit_score 300–850.
  - Commercial requires either noi_annual or rental_income; residential DSCR path requires rental_income.
  - Fix-and-Flip requires rehab_budget and either as_is_value or after_repair_value.
  - On submit, reject unknown enums, missing conditionals, and inconsistent combos (e.g., Owner-Occ with DSCR for residential).
- Matching trigger: successful submit enqueues match job; scenario core fields become immutable.
- Idempotency: All POST endpoints accept Idempotency-Key header; duplicate keys within 24h return the original response.

API endpoints
- POST /v1/scenarios/drafts
  - Auth: broker/admin
  - Body: partial scenario payload
  - Behavior: create draft; basic schema validation only; returns {scenario_id, state:"draft"}
  - 201 Created; 400 on schema error
- PATCH /v1/scenarios/{scenario_id}
  - Auth: owner broker/admin
  - Body: partial; allowed only in draft state
  - 200 OK with full scenario; 409 if not in draft
- POST /v1/scenarios/validate
  - Auth: broker/admin
  - Body: full scenario payload
  - Behavior: dry-run strong validation + derived metrics; no persistence
  - 200 OK {valid: bool, errors:[], warnings:[], derived:{ltv, ltc}}
- POST /v1/scenarios/{scenario_id}/submit
  - Auth: owner broker/admin
  - Behavior: strong validation; compute derived; persist; enqueue matching; set state=submitted
  - Response: 202 Accepted {scenario_id, state:"submitted", match_job_id}
  - Errors: 400/422 validation; 409 if already submitted/archived
- GET /v1/scenarios/{scenario_id}
  - Auth: owner broker/admin
  - Returns scenario with derived fields and state
- Security & tenancy
  - OAuth/JWT; verify account_id ownership on every read/write.
  - Field-level sanitation, enum allowlists, numeric bounds, and input normalization (trim, uppercase state).
  - Audit log: actor_id, action, timestamp, diff for create/update/submit.
- Performance
  - Draft save/patch: p95 < 250ms
  - Validate: p95 < 300ms
  - Submit (excluding matching): p95 < 800ms; enqueue within 200ms
  - Rate limiting: 60 write ops/min per user; 5 submits/min per user.

User-facing flows
- Create draft -> iteratively PATCH until complete -> optional POST /validate for checks -> POST /submit -> receive match_job_id -> client proceeds to matching status screens elsewhere.
- Edge cases: attempting submit with missing conditionals returns 422; editing submitted scenario returns 409; idempotent re-submit with same Idempotency-Key returns same 202.

Acceptance criteria
- Drafts allow partial payloads; server returns only sanitized and stored fields.
- Submit enforces all conditional requirements per channel/purpose and rejects invalid combinations.
- Derived metrics are computed server-side and returned; client-submitted derived fields are ignored.
- Scenario ownership is enforced; cross-tenant access returns 404.
- Idempotency prevents duplicate scenario creation/submission on retries.
- Successful submit creates a persistent scenario with state=submitted and enqueues a match job.
- All validation errors return machine-readable paths and codes.

Out of scope
- UI rendering, field labels, or client-side validation UX
- Matching engine logic/results, comparisons, and lender communications
- Document uploads, KYC/AML, and credit pulls
- PDF generation or email delivery of results