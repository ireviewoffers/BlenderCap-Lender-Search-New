# Database PRD: Loan Scenario Search Form
**Feature:** Loan Scenario Search Form  
**Type:** database

## Feature Summary
Persistent data model for the Loan Scenario Search Form that captures broker-entered deal inputs for qualification and lender matching. Supports: draft/edit/submit, residential vs commercial branching, versioned form definitions, normalized answers for flexibility, and denormalized scenario facets for fast search, filtering, and scoring.

## Scope
- Store form definitions (fields, validation, visibility rules) by version.
- Store scenario records with both raw answers and indexed facets.
- Support drafts, cloning, soft delete, and submission timestamps.
- Preserve compatibility when form versions change.

## Entities & Relationships
- form_fields_catalog (versioned field registry) → referenced by loan_scenario_answers.field_key and loan_scenarios.form_version.
- loan_scenarios (one per scenario) → parent for answers; includes denormalized facets for search.
- loan_scenario_answers (many per scenario) → raw responses keyed by field_key.

## Constraints & Data Integrity
- loan_scenarios.scenario_type ∈ {residential, commercial}.
- Status ∈ {draft, submitted, archived}.
- field_key must exist in catalog for the matching form_version at submission time; drafts may contain provisional keys.
- One active answer per (scenario_id, field_key).
- Numeric bounds enforced in validation JSON (catalog) and optionally at submission time; DB stores as NUMERIC/INT without implicit rounding.
- Time fields in TIMESTAMPTZ; date-only in DATE.

## Indexing & Query Patterns
- High-selectivity composite indexes for lender matching and search: scenario_type + property_state + loan_purpose, dscr, ltv, ltc, loan_amount, occupancy, property_type, credit_score.
- GIN indexes for answers.value_json (arrays/multi-select) and catalog.options/visibility/validation.
- Filter by status and submitted_at for active matching queues.

## Denormalized Facets (loan_scenarios)
- Property: property_state, city/county/zip, property_type, units, occupancy.
- Loan request: purpose, amount, purchase_price, as_is_value, arv, rehab_budget, ltv, ltc, term_months, interest_only, prepayment_penalty, requested_closing_date.
- Underwriting: dscr, credit_score, doc_type, experience_years.

## Edge Cases
- Multi-select answers stored as JSON array in value_json; single-select as value_text.
- Unknown/Not provided: omit answer row or leave all value_* NULL; facets on loan_scenarios remain NULL and are excluded from strict filters.
- Cloning preserves answers and facets but resets status=draft, submitted_at=NULL; linked via cloned_from_id.
- Versioning: scenarios record form_version at creation; answer validation uses that version even if catalog updates later.
- Soft delete via deleted_at; unique constraints consider non-deleted rows.

## Security & Access
- broker_user_id ownership required for RLS (not defined here) to restrict access to owner and privileged roles.
- No borrower PII in this feature; notes free-text field is non-PII by guidance.
