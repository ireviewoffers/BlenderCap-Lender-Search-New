# Frontend PRD: Loan Scenario Search Form
**Feature:** Loan Scenario Search Form  
**Type:** frontend

# Loan Scenario Search Form

## Feature overview
Mobile-first, conditional questionnaire that captures deal details to qualify and match lenders. Supports Residential and Commercial scenarios with dynamic fields, inline validations, and a single Submit action that triggers the matching engine. Enables brokers to quickly input essentials, review, and run a search with minimal friction.

## Scope & behavior
- Entry points
  - New Scenario CTA from dashboard, header, or “Clone” existing scenario (prefills; clone mechanics out of scope).
  - Accessible only to authenticated users with Broker role. Non-brokers see disabled form with tooltip “Broker access required.”
- Form structure (4-step wizard with progress indicator; all steps navigable back/forward)
  1) Deal Type & Basics
  2) Property & Borrower
  3) Loan Request
  4) Review & Submit
- Core fields and conditional logic
  - Global required: Deal Type (Residential | Commercial), Loan Purpose (Purchase | Rate/Term Refi | Cash‑out Refi), State, Property City, ZIP, Estimated Value (or Purchase Price for Purchase), Requested Loan Amount.
  - Residential-specific:
    - Property Type (SFR, Condo, 2–4 Unit, 5+ Unit routed to Commercial warning), Occupancy (Owner‑Occ | Second Home | Investment), Units (auto = 1 for SFR/Condo; 2–4 for Multi).
    - Borrower Credit Score (300–850), DTI (%) for Owner‑Occ, DSCR optional for Investment.
    - Income Doc Type (Full | Bank Statements | DSCR/No‑Ratio | WVOE), First‑time Investor (Y/N).
  - Commercial-specific:
    - Asset Type (Multifamily, Mixed‑Use, Retail, Office, Industrial, Self‑Storage, Hospitality, Specialty).
    - Units (if applicable), Net Operating Income (annual), CapEx (optional), DSCR (calc or input), Tenant Concentration (optional).
    - Borrower Experience (count of stabilized exits or years), Entity Type (LLC, LP, Corp, Individual).
  - Loan Request (both):
    - Purchase Price (if Purchase) else Appraised/As‑Is Value; Rehab Budget (optional); As‑Complete Value (optional).
    - LTV/LTC auto‑calculated; editable Requested Loan Amount; Term (months/years), Amortization (IO | Amortizing), Fixed Period, Prepayment Sensitivity (Flexible | Moderate | Rigid).
    - Closing Timeline (Urgent ≤15d | 30–45d | 60d+), Broker Fee (bps or $), Notes to Lenders (free text).
- Validation and formatting
  - Numeric/monetary inputs: currency mask with thousand separators; percent fields 0–100; DSCR 0–5; credit 300–850; ZIP length by country (US 5).
  - Cross-field checks:
    - Requested Loan Amount ≤ max of LTV/LTC constraints based on entered values; warn when exceeds common thresholds (e.g., Resi LTV > 90%).
    - For Residential Owner‑Occ: DTI required; DSCR hidden. For Investment: DSCR encouraged; DTI hidden.
    - For Commercial: require NOI when DSCR not provided; if both present, recalc DSCR = NOI/Annual Debt Service and display non-blocking delta if user-entered differs >0.05.
  - Errors: inline, below field, concise; form-level banner for blocking issues on submit.
- States
  - Pristine, Dirty, Valid, Invalid, Submitting (disabled inputs + spinner on CTA), Submit Error (retry), Autosaving (silent).
- Drafts & autosave
  - Autosave every 3 seconds after change or on step change; last-saved timestamp in header.
  - Draft persists per user until submit; multiple drafts allowed.
- Review step
  - Read-only summary grouped by step, with “Edit” anchors back to sections.
  - Display computed metrics: LTV, LTC, DSCR (if derivable), All‑in Sources/Uses (if rehab provided).
- Submission
  - CTA: “Search Lenders”. On success, route to Results with scenario ID. On failure, keep on Review, show banner with error and retain inputs.

## User-facing flows
- Start new Residential Purchase
  - Select Residential → Purchase → enter State/ZIP → SFR → Investment → value, price, loan amount → DSCR (optional) → Review → Submit → Results.
- Switch type mid-flow
  - Changing Deal Type triggers confirmation modal: “Switching will reset incompatible fields.” On confirm, non-overlapping fields reset; shared fields persist.
- Over-limit loan amount
  - If Requested > computed LTV cap: red helper text and disable Submit until corrected or user lowers amount.
- Missing critical field on submit
  - Form scrolls to first error, focuses field, announces via ARIA-live.

## Acceptance criteria
- Mobile: 360px width supports all steps without horizontal scroll; sticky step header and Submit bar on small screens.
- Accessibility: WCAG AA; labels bound; error messaging announced; keyboard-only navigation across all inputs and stepper.
- Conditional fields show/hide instantly with no layout jumps >100px; hidden fields do not validate or submit.
- Currency/percent masks maintain raw numeric values in state; copying/pasting works.
- Autosave writes within 500ms after idle; network failure shows non-blocking toast and retries.
- LTV/LTC/DSCR auto-calculations update within 100ms after dependent changes.
- Submit disabled when any required-visible field invalid; enabled otherwise.
- On success, user lands on Results within 2s with scenario data carried over.
- Unauthorized users see disabled form and sign-in prompt link.

## Out of scope
- Lender results ranking, comparison, and messaging.
- Document upload, PDF/email generation.
- Pricing, fees, or rate quotes beyond input capture.
- Back-office review or workflow management.