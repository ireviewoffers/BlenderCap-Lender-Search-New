# Blender Cap Lender Search — Cursor Runbook

> Keep this file open while building. Follow phases in order. Complete each phase before starting the next.

## How to use this runbook
1. Open Cursor IDE in your project folder
2. Open the Chat panel (Cmd+L)
3. For each phase: paste the "Say this to Cursor" prompt, wait for Cursor to finish, then run the verification steps
4. Only move to the next phase when verification passes

## Project Overview
Blender Cap Lender Search is a web application designed to help brokers find the right lenders for residential and commercial loans. It provides a robust search engine with advanced filtering options, confidence-based matching, and a mini-CRM to track interactions with lenders.

## Tech Stack
- Modern Web App (Next.js + TypeScript)
- Reliable Database (Postgres)
- Search & Filtering (Full-text and faceted search)
- Authentication & Roles (Secure accounts)
- PDF & Email Delivery (Generate lender-ready documents)
- Responsive web app (Mobile-first UI)

---

## Phase 0: Project Setup
**What this phase does:** Scaffold the project structure and install dependencies.

**Say this to Cursor:**
```
Read my .codespring/ folder to understand the project. Then scaffold the codespring project structure with all dependencies installed and a working dev server.
```

**How to verify it worked:**
- [ ] Dev server starts without errors (npm run dev / yarn dev)
- [ ] You can open localhost:3000 in a browser
- [ ] No TypeScript errors in the terminal

**If something breaks, say this to Cursor:**
```
The setup failed with this error: [paste error here]. Fix it without changing the project structure.
```

---

## Phase 1: Two-Path Landing Gateway
**What this phase does:** Build the homepage that allows users to choose between finding residential or commercial lenders.

**Say this to Cursor:**
```
Implement a two-path landing gateway that routes users to either the Residential or Commercial lender search. Use Next.js for routing and ensure the UI is responsive.
```

**How to verify it worked:**
- [ ] The homepage displays two options: "Find Residential Lenders" and "Find Commercial Lenders."
- [ ] Clicking each option routes to the respective search page.
- [ ] The layout is mobile-friendly.

**If something breaks, say this to Cursor:**
```
The two-path landing gateway failed with this error: [paste error here]. Fix it without changing the project structure.
```

---

## Phase 2: Loan Scenario Search Engine
**What this phase does:** Create the core form for inputting deal parameters to find matching lenders.

**Say this to Cursor:**
```
Build a loan scenario search engine that includes a form for brokers to input deal parameters. Ensure all fields are required and validate inputs before submission.
```

**How to verify it worked:**
- [ ] The form captures all necessary deal parameters.
- [ ] Validation prevents submission with incomplete fields.
- [ ] Successful submission triggers a lender search.

**If something breaks, say this to Cursor:**
```
The loan scenario search engine failed with this error: [paste error here]. Fix it without changing the project structure.
```

---

## Phase 3: Advanced Deal Filters
**What this phase does:** Implement advanced filters for loan purpose, amount ranges, property type, and other criteria.

**Say this to Cursor:**
```
Add advanced deal filters to the loan scenario search engine, allowing brokers to refine their search based on loan purpose, amount ranges, property type, occupancy, location, FICO, LTV, documentation type, borrower type, product type, and closing speed.
```

**How to verify it worked:**
- [ ] Filters are functional and update the lender search results in real time.
- [ ] All filter options are clearly labeled and easy to use.
- [ ] The form remains responsive on mobile devices.

**If something breaks, say this to Cursor:**
```
The advanced deal filters failed with this error: [paste error here]. Fix it without changing the project structure.
```

---

## Phase 4: Confidence-Based Matching
**What this phase does:** Implement a scoring system that ranks lenders based on their fit for the loan scenario.

**Say this to Cursor:**
```
Create a confidence-based matching system that ranks lenders as Strong fit, Possible fit, or Stretch fit. Provide plain-English explanations for each ranking based on the input parameters.
```

**How to verify it worked:**
- [ ] Lenders are ranked correctly based on the input parameters.
- [ ] Explanations for each ranking are clear and understandable.
- [ ] The scoring system integrates seamlessly with the search results.

**If something breaks, say this to Cursor:**
```
The confidence-based matching failed with this error: [paste error here]. Fix it without changing the project structure.
```

---

## Phase 5: Side-by-Side Lender Comparison
**What this phase does:** Enable brokers to compare multiple lenders side-by-side based on key criteria.

**Say this to Cursor:**
```
Build a side-by-side comparison feature that allows brokers to compare lenders on attributes such as leverage, min FICO, documentation requirements, and other key terms.
```

**How to verify it worked:**
- [ ] Brokers can select multiple lenders for comparison.
- [ ] The comparison displays key attributes clearly.
- [ ] Users can easily identify differences between lenders.

**If something breaks, say this to Cursor:**
```
The side-by-side lender comparison failed with this error: [paste error here]. Fix it without changing the project structure.
```

---

## Phase 6: Scenario Memory & Mini-CRM
**What this phase does:** Implement functionality to save and track loan scenarios and lender interactions.

**Say this to Cursor:**
```
Create a mini-CRM feature that allows brokers to save, clone, and track loan scenarios. Include functionality to log replies and quotes from lenders.
```

**How to verify it worked:**
- [ ] Brokers can save and clone scenarios successfully.
- [ ] The system tracks replies and quotes from lenders.
- [ ] Users can view the status and probability of closing for each scenario.

**If something breaks, say this to Cursor:**
```
The scenario memory and mini-CRM failed with this error: [paste error here]. Fix it without changing the project structure.
```

---

## Final Phase: Testing & Polish
**Say this to Cursor:**
```
Review the entire codebase. Fix any TypeScript errors, broken imports, or missing connections between features. Make sure all features from the .codespring/PRDs/ folder are implemented.
```

**How to verify the full app works:**
- [ ] All features function as intended without errors.
- [ ] The app is responsive and works on both mobile and desktop.
- [ ] All user inputs are validated correctly.
- [ ] Lender matches and comparisons are accurate.
- [ ] The mini-CRM tracks scenarios and lender interactions effectively.