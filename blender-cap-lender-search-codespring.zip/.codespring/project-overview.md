# Blender Cap Lender Search — Overview

Blender Cap Lender Search is a mobile-friendly matchmaking engine for loan scenarios. Brokers choose Residential or Commercial, enter deal details, and get lenders whose underwriting guidelines match—ranked by confidence with clear explanations. Includes side-by-side comparisons plus save, clone, and track scenarios.

## Features
- **Two-Path Landing Gateway**: Homepage choice: Find Residential Lenders or Find Commercial Lenders; sets the filtering framework.
- **Loan Scenario Search Engine**: Core form to input deal parameters and return matching lenders by underwriting guidelines.
- **Advanced Deal Filters**: Loan purpose, amount ranges, property type, occupancy, location, FICO, LTV, docs type, borrower type, product type, closing speed.
- **Confidence-Based Matching**: Ranks results as Strong fit (90–100%), Possible fit (80–89%), Stretch fit (≤79%) with plain‑English reasons.
- **Side-by-Side Lender Comparison**: Compare leverage, min FICO, docs, prepay, loan size, geography, entity rules, seasoning, STR, rehab draws, valuation, timeline.
- **Scenario Memory & Mini‑CRM**: Save/clone scenarios, resend to lenders, track replies and quotes, log fallout reasons, track close probability.
- **Response Quality Ranking**: Score lenders by response time, quote rate, close rate, program freshness, broker satisfaction.
- **Broker Panels & Favorite Stacks**: Curated stacks like top bridge lenders, DSCR stack, aggressive leverage, fast close, regional stacks.
- **Admin Dashboard**: Monitor lenders in database and how often they appear as Strong/Possible/Stretch fits.
- **Package Generator**: Create lender-ready scenario summary as PDF or email sheet.
- **Learn Content Layer**: Guides and content to help choose the right product for a deal.
- **Loan Scenario Search (Match)**: Deal form + filters to find lenders whose underwriting matches.
- **Confidence-Based Matching**: Score lenders as Strong/Possible/Stretch with clear explanation of fit.
- **Side-by-Side Comparison (Compare)**: Compare leverage, FICO, docs, prepay, size, geo, rules, STR, draws, timeline.
- **Scenario Memory + Mini-CRM (Track)**: Save/clone scenarios, outreach, log quotes, replies, and close probability.
- **Response-Quality Ranking**: Rank by response time, quote rate, close rate, fallout, freshness, satisfaction.
- **Broker Favorite Stacks**: Custom lender groups (bridge, DSCR, fast close, aggressive leverage, regions).
- **Admin Dashboard**: Lender database stats and result distribution (Strong/Possible/Stretch).
- **Packaging (PDF/Email)**: Generate lender-ready scenario summary as PDF or email.
- **Learn Content Layer**: Guides for “what product fits this deal?” searchable and linked to filters.
- **Loan Scenario Search (Match)**: Core search where brokers input deal parameters and get lender matches.
- **Advanced Deal Filters & Questionnaire**: Purpose, amount, property type, occupancy, location, FICO, LTV, docs, borrower type, product type, closing speed.
- **Confidence-Based Matching with Explanations**: Groups results as Strong/Possible/Stretch with plain-language reasons for fit or gaps.
- **Side-by-Side Lender Comparison (Compare)**: Compare leverage, min FICO, docs, prepay, loan size, geo appetite, rules, STR, rehab draws, valuation, timelines.
- **Scenario Memory & Mini-CRM (Track)**: Save, clone, resend scenarios; log quotes; track replies and close probability.
- **Response-Quality Ranking**: Rank lenders by response time, quote rate, close rate, fallout reasons, program freshness, broker satisfaction.
- **Broker Favorite Stacks**: Custom lender stacks (bridge, DSCR, aggressive leverage, fast close, regional).
- **Admin Dashboard**: Monitor lender database and how often lenders appear in Strong/Possible/Stretch categories.
- **Package (PDF/Email Summary)**: Generate lender-ready summary sheets for outreach.
- **Learn (Guides & Playbooks)**: Content layer explaining which products fit which deals.
- **Two-Path Gateway**: Homepage choice: Find Residential Lenders vs Find Commercial Lenders with tailored filters.
- **Two‑Path Gateway (Residential vs Commercial)**: Homepage choice that routes users into tailored filter frameworks.
- **Loan Scenario Search Form**: Core questionnaire for deal qualification and lender matching.
- **Advanced Deal Filters**: Purpose, amount, property/occupancy, location, FICO, LTV, docs type, borrower, product, closing speed.
- **Confidence‑Based Matching + Explanations**: Strong/Possible/Stretch fit bands with human‑readable reasons.
- **Side‑by‑Side Lender Comparison**: Compare leverage, min FICO, docs, prepay, size, geo, entity rules, seasoning, STR, rehab draws, valuation, timelines.
- **Scenario Memory & Mini‑CRM**: Save/clone scenarios, resend, track replies, log quotes, close probability.
- **Response‑Quality Ranking**: Rank by response time, quote rate, close rate, fallout reasons, freshness, broker satisfaction.
- **Broker Favorite Stacks**: Curated lender sets: bridge, DSCR, aggressive leverage, fast close, regional stacks.
- **Admin Dashboard**: Lender/program management and visibility into Strong/Possible/Stretch result counts.
- **Package (PDF/Email)**: Generate lender‑ready scenario summaries for outreach.
- **Residential Path — Filter Pack**: Loan purpose, property subtype (SFR, condo, townhome, 2–4 unit, STR), occupancy, state/city, FICO bands, LTV, DSCR/No‑doc, closing speed.
- **Commercial Path — Filter Pack**: Property type (office, retail, industrial, hospitality, mixed‑use, land), loan size bands, entity/foreign national, docs type, LTV/LTC, closing speed.
- **Confidence Scoring + Explanations**: Ranks lenders as Strong/Possible/Stretch with bulletproof why/why‑not rationales mapped to each filter and lender guideline.
- **Side‑by‑Side Comparison Workspace**: Compare leverage, min FICO, docs, prepay, size, geo appetite, entity rules, seasoning, STR, rehab draws, valuation, and timeline.
- **Scenario Memory & CRM Loop**: Save/clone scenarios, resend to lenders, log quotes, track replies, status, and close probability.
- **Response‑Quality Ranking**: Order by average response time, quote rate, close rate, fallout reasons, program freshness, broker satisfaction.
- **Broker Favorite Stacks**: Custom lender groups (Top bridge, DSCR stack, aggressive leverage, fast close, NC/SC investor).
- **Admin Dashboard Metrics**: Lender coverage, appearances in Strong/Possible/Stretch, program freshness signals, data quality alerts.
- **Package Generator**: Create lender‑ready PDF/email with scenario summary, comps, photos/links, and key underwriting fields.
- **Residential Search Inputs & Filters**: Purpose, amount bands, property type (SFR, condo, townhome, 2–4 unit, multifamily), occupancy, state/city, FICO bands, LTV, docs (full/bank stmt/DSCR/no‑doc), borrower type, product type, closing speed. Presets, progressive disclosure, validation.
- **Commercial Search Inputs & Filters**: Purpose, amount bands incl. $1M+, property type (office, retail, industrial, hospitality, mixed‑use, land, gas station, cannabis), occupancy, geography, FICO/alt credit, LTV/LTC, docs, entity type, product type (bridge/construction), closing speed. Presets and validation.
- **Loan Scenario Search Form — Field Requirements**: All fields are mandatory for BOTH Residential and Commercial paths: Loan Purpose, Loan Amount, Property Type, Occupancy, Property Location (state/city), Credit Score, LTV, Documentation Type, Borrower Type, Loan Product Type, Closing Speed. Enforce: required validation, inline errors, disabled submit until complete, clear prompts, and consistent requiredness across both paths.

## Tech Stack
- Modern Web App (Next.js + TypeScript for a fast, mobile‑friendly frontend with server rendering.)
- Reliable Database (Postgres for structured lender programs, underwriting rules, and scenarios.)
- Search & Filtering (Full‑text and faceted search for lender/program matching with scoring.)
- Authentication & Roles (Secure accounts with broker, lender, and admin roles.)
- PDF & Email Delivery (Generate lender‑ready PDFs and send scenario packages and updates.)
- Responsive web app (Mobile‑first UI with fast search and clean forms)
- Reliable database (Structured storage for lenders, programs, scenarios, and activity)
- Search + scoring engine (Rule/weighting based matcher with confidence bands and explanations)
- Accounts & authentication (Secure login, roles for brokers, lenders, and admins)
- Docs & messaging (Generate PDF/email packages and send updates/notifications)
- Modern web app (Responsive website optimized for mobile and desktop)
- Secure accounts & auth (Broker and lender sign-in with role-based access)
- Reliable relational database (Stores lenders, programs, guidelines, scenarios, and activity)
- Search + matching engine (Scores lender fit and explains Strong/Possible/Stretch results)
- Document/PDF generator (Creates lender-ready scenario packets for outreach)
- Email & notifications (Sends scenario shares, quote requests, and status updates)
- Modern web app framework (Fast, responsive UI with server and client rendering)
- Reliable relational database (Structured data for lenders, programs, scenarios, and activity logs)
- Secure authentication & roles (Broker, lender, and admin access with permissions)
- PDF/email generation service (Create and send lender-ready scenario packages)
- Search, filtering & scoring engine (Guideline-based matching with explanation scoring)

> Generated by CodeSpring on 2026-05-09